/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel;

import java.util.Map;

/**
 * RList
 *
 * @author Przemyslaw Sikora
 */
public class RList implements RObject {

    private Map<String, RObject> value;

    public RList() {
    }

    public RList(Map<String, RObject> value) {
        this.value = value;
    }

    public Map<String, RObject> getValue() {
        return value;
    }

    public void setValue(Map<String, RObject> value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RList rList = (RList) o;

        return value != null ? value.equals(rList.value) : rList.value == null;
    }

    @Override
    public int hashCode() {
        return value != null ? value.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "RList{" +
                "value=" + value +
                '}';
    }
}