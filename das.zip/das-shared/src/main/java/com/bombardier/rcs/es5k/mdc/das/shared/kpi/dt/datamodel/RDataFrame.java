/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel;

import java.util.List;
import java.util.Map;

/**
 * RDataFrame
 *
 * @author Przemyslaw Sikora
 */
public class RDataFrame implements RObject {

    private Map<String, List<RPrimitive>> value;

    public RDataFrame() {
    }

    public RDataFrame(Map<String, List<RPrimitive>> value) {
        this.value = value;
    }

    public Map<String, List<RPrimitive>> getValue() {
        return value;
    }

    public void setValue(Map<String, List<RPrimitive>> value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RDataFrame that = (RDataFrame) o;

        return value != null ? value.equals(that.value) : that.value == null;
    }

    @Override
    public int hashCode() {
        return value != null ? value.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "RDataFrame{" +
                "value=" + value +
                '}';
    }
}