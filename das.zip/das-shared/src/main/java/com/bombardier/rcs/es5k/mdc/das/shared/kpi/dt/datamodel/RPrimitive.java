/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel;

/**
 * RPrimitive
 *
 * @author Przemyslaw Sikora
 */
public interface RPrimitive extends RObject {
}
