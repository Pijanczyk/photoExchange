/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel;

/**
 * RInteger
 *
 * @author Przemyslaw Sikora
 */
public class RInteger implements RPrimitive {

    private Integer value;

    public RInteger() {
    }

    public RInteger(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RInteger rInteger = (RInteger) o;

        return value != null ? value.equals(rInteger.value) : rInteger.value == null;
    }

    @Override
    public int hashCode() {
        return value != null ? value.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "RInteger{" +
                "value=" + value +
                '}';
    }
}
