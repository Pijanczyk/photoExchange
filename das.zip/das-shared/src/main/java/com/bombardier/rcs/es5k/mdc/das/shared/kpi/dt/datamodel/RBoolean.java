/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel;

/**
 * RBoolean
 *
 * @author Przemyslaw Sikora
 */
public class RBoolean implements RPrimitive {

    private Boolean value;

    public RBoolean() {
    }

    public RBoolean(Boolean value) {
        this.value = value;
    }

    public Boolean getValue() {
        return value;
    }

    public void setValue(Boolean value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RBoolean rBoolean = (RBoolean) o;

        return value != null ? value.equals(rBoolean.value) : rBoolean.value == null;
    }

    @Override
    public int hashCode() {
        return value != null ? value.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "RBoolean{" +
                "value=" + value +
                '}';
    }
}
