/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt;

import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel.SpecificKpiConfiguration;
import org.bson.Document;

/**
 * Kpi Configuration To Document Converter
 *
 * @author Przemyslaw Sikora
 */
public interface KpiConfigurationToDocumentConverter {

    Document convertToDocument(SpecificKpiConfiguration configuration);

    SpecificKpiConfiguration convertToKpiConfiguration(Document document);

}
