/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel;

import java.util.List;

/**
 * RVector
 *
 * @author Przemyslaw Sikora
 */
public class RVector implements RObject {

    private List<RObject> value;

    public RVector() {
    }

    public RVector(List<RObject> value) {
        this.value = value;
    }

    public List<RObject> getValue() {
        return value;
    }

    public void setValue(List<RObject> value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RVector rVector = (RVector) o;

        return value != null ? value.equals(rVector.value) : rVector.value == null;
    }

    @Override
    public int hashCode() {
        return value != null ? value.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "RVector{" +
                "value=" + value +
                '}';
    }
}
