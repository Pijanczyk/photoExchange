/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Data Priority
 *
 * @author Przemyslaw Sikora
 */
public enum DataPriority {

    SOURCE("source"), EPISODE("episode");

    private String name;

    DataPriority(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    public static DataPriority fromString(String name) {
        for (DataPriority priority : DataPriority.values()) {
            if (priority.name.equals(name)) {
                return priority;
            }
        }
        throw new IllegalArgumentException(String.format("Unrecognized data priority (%s)", name));
    }

}
