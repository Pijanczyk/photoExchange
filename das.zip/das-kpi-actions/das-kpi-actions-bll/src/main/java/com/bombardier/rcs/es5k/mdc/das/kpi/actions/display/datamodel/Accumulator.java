/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Accumulator
 *
 * @author Przemyslaw Sikora
 */
public enum Accumulator {

    SUM("sum"), AVERAGE("avg"), MINIMUM("min"), MAXIMUM("max");

    private String name;

    Accumulator(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    public static Accumulator fromString(String name) {
        for (Accumulator accumulator : Accumulator.values()) {
            if (accumulator.name.equals(name)) {
                return accumulator;
            }
        }
        throw new IllegalArgumentException(String.format("Unrecognized accumulator (%s)", name));
    }

}
