/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Average Mode
 *
 * @author Przemyslaw Sikora
 */
public enum AverageMode {

    AVERAGE_OF_THE_AVERAGES("avgOfAvgs"), AVERAGE_OF_ALL("avgOfAll");

    private String name;

    AverageMode(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    public static AverageMode fromString(String name) {
        for (AverageMode mode : AverageMode.values()) {
            if (mode.name.equals(name)) {
                return mode;
            }
        }
        throw new IllegalArgumentException(String.format("Unrecognized average mode (%s)", name));
    }

}
