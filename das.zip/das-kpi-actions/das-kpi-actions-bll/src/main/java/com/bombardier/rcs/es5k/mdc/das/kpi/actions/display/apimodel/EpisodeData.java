/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.apimodel;

import javax.validation.constraints.NotNull;

/**
 * Episode Data
 *
 * @author Przemyslaw Sikora
 */
public class EpisodeData {

    /**
     * Reference of an episode or episode ratio
     */
    private String reference;

    /**
     * Presentation name of an episode (episode ratio)
     */
    private String name;

    /**
     * Data
     */
    @NotNull
    private Double[][] data;

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double[][] getData() {
        return data;
    }

    public void setData(Double[][] data) {
        this.data = data;
    }
}
