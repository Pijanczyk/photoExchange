/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel;

import java.io.Serializable;
import java.util.Set;

/**
 * Data Filter
 *
 * @author Przemyslaw Sikora
 */
public class DataFilter implements Serializable {

    private Set<ObjectFilter> facilities;
    private Set<ObjectFilter> systems;
    private Set<ObjectFilter> devices;
    private Set<ObjectFilter> deviceTypes;

    public Set<ObjectFilter> getFacilities() {
        return facilities;
    }

    public void setFacilities(Set<ObjectFilter> facilities) {
        this.facilities = facilities;
    }

    public Set<ObjectFilter> getSystems() {
        return systems;
    }

    public void setSystems(Set<ObjectFilter> systems) {
        this.systems = systems;
    }

    public Set<ObjectFilter> getDevices() {
        return devices;
    }

    public void setDevices(Set<ObjectFilter> devices) {
        this.devices = devices;
    }

    public Set<ObjectFilter> getDeviceTypes() {
        return deviceTypes;
    }

    public void setDeviceTypes(Set<ObjectFilter> deviceTypes) {
        this.deviceTypes = deviceTypes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DataFilter that = (DataFilter) o;

        if (facilities != null ? !facilities.equals(that.facilities) : that.facilities != null) return false;
        if (systems != null ? !systems.equals(that.systems) : that.systems != null) return false;
        if (devices != null ? !devices.equals(that.devices) : that.devices != null) return false;
        return deviceTypes != null ? deviceTypes.equals(that.deviceTypes) : that.deviceTypes == null;
    }

    @Override
    public int hashCode() {
        int result = facilities != null ? facilities.hashCode() : 0;
        result = 31 * result + (systems != null ? systems.hashCode() : 0);
        result = 31 * result + (devices != null ? devices.hashCode() : 0);
        result = 31 * result + (deviceTypes != null ? deviceTypes.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "DataFilter{" +
                "facilities=" + facilities +
                ", systems=" + systems +
                ", devices=" + devices +
                ", deviceTypes=" + deviceTypes +
                '}';
    }

}
