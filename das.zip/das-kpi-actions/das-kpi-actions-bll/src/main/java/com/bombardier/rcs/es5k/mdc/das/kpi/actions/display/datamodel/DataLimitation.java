/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

/**
 * Data Limitation
 *
 * @author Przemyslaw Sikora
 */
public class DataLimitation {

    private Integer sourcesMax;
    private Integer episodesMax;
    private DataPriority dataPriority;
    private ValueProperty valueProperty;
    private Accumulator accumulator;
    private TargetProperty targetProperty;

    public Integer getSourcesMax() {
        return sourcesMax;
    }

    public void setSourcesMax(Integer sourcesMax) {
        this.sourcesMax = sourcesMax;
    }

    public Integer getEpisodesMax() {
        return episodesMax;
    }

    public void setEpisodesMax(Integer episodesMax) {
        this.episodesMax = episodesMax;
    }

    public DataPriority getDataPriority() {
        return dataPriority;
    }

    public void setDataPriority(DataPriority dataPriority) {
        this.dataPriority = dataPriority;
    }

    public ValueProperty getValueProperty() {
        return valueProperty;
    }

    public void setValueProperty(ValueProperty valueProperty) {
        this.valueProperty = valueProperty;
    }

    public Accumulator getAccumulator() {
        return accumulator;
    }

    public void setAccumulator(Accumulator accumulator) {
        this.accumulator = accumulator;
    }

    public TargetProperty getTargetProperty() {
        return targetProperty;
    }

    public void setTargetProperty(TargetProperty targetProperty) {
        this.targetProperty = targetProperty;
    }
}
