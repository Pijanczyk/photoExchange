/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel;

import java.io.Serializable;
import java.time.Duration;
import java.util.Set;

/**
 * Episode Filter
 *
 * @author Przemyslaw Sikora
 */
public class EpisodeFilter implements Serializable {

    private Duration minimumDuration;
    private Duration maximumDuration;
    private Set<MeasurementCondition> measurementConditions;

    public Duration getMinimumDuration() {
        return minimumDuration;
    }

    public void setMinimumDuration(Duration minimumDuration) {
        this.minimumDuration = minimumDuration;
    }

    public Duration getMaximumDuration() {
        return maximumDuration;
    }

    public void setMaximumDuration(Duration maximumDuration) {
        this.maximumDuration = maximumDuration;
    }

    public Set<MeasurementCondition> getMeasurementConditions() {
        return measurementConditions;
    }

    public void setMeasurementConditions(Set<MeasurementCondition> measurementConditions) {
        this.measurementConditions = measurementConditions;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EpisodeFilter that = (EpisodeFilter) o;

        if (minimumDuration != null ? !minimumDuration.equals(that.minimumDuration) : that.minimumDuration != null)
            return false;
        if (maximumDuration != null ? !maximumDuration.equals(that.maximumDuration) : that.maximumDuration != null)
            return false;
        return measurementConditions != null ? measurementConditions.equals(that.measurementConditions) : that.measurementConditions == null;
    }

    @Override
    public int hashCode() {
        int result = minimumDuration != null ? minimumDuration.hashCode() : 0;
        result = 31 * result + (maximumDuration != null ? maximumDuration.hashCode() : 0);
        result = 31 * result + (measurementConditions != null ? measurementConditions.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "EpisodeFilter{" +
                "minimumDuration=" + minimumDuration +
                ", maximumDuration=" + maximumDuration +
                ", measurementConditions=" + measurementConditions +
                '}';
    }
}
