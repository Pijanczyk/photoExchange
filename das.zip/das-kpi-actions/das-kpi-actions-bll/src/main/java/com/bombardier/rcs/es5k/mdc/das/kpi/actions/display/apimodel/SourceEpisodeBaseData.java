/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.apimodel;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Source Episode Base Data
 *
 * @author Przemyslaw Sikora
 */
public class SourceEpisodeBaseData {

    /**
     * Reference of a source object.
     */
    private String reference;

    /**
     * Presentation name of a source object.
     */
    private String name;

    /**
     * List of episodes that contain data produced by the source object
     */
    @NotNull
    private List<EpisodeData> episodes;

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<EpisodeData> getEpisodes() {
        return episodes;
    }

    public void setEpisodes(List<EpisodeData> episodes) {
        this.episodes = episodes;
    }
}
