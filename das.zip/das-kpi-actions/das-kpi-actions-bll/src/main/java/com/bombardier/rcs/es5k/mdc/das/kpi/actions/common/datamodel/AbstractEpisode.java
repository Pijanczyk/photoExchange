/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.common.datamodel;

import com.bombardier.rcs.mdc.model.AbstractEntity;

import java.time.ZonedDateTime;

/**
 * Abstract Episode
 *
 * @author Przemyslaw Sikora
 */
public class AbstractEpisode extends AbstractEntity {

    private String reference;
    private String name;
    private ZonedDateTime timestamp;

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ZonedDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(ZonedDateTime timestamp) {
        this.timestamp = timestamp;
    }

}
