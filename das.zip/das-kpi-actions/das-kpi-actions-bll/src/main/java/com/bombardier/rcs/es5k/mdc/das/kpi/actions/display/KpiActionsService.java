/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.common.EpisodeRatioRepository;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.common.EpisodeRepository;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.apimodel.ActionsDataSet;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.apimodel.EpisodeData;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.apimodel.SourceEpisodeBaseData;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.*;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.KpiActionsDataRequest;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.TimeGranularity;
import com.bombardier.rcs.es5k.mdc.das.kpi.core.display.datamodel.KpiConfiguration;
import com.bombardier.rcs.es5k.mdc.das.kpi.core.display.datamodel.KpiLocationConfiguration;
import com.bombardier.rcs.es5k.mdc.das.kpi.core.display.datamodel.SdiObjectPageType;
import com.bombardier.rcs.mdc.exception.EntityNotFoundException;
import com.bombardier.rcs.mdc.sdi.model.SDIDevice;
import com.bombardier.rcs.mdc.sdi.model.SDIDeviceType;
import com.bombardier.rcs.mdc.sdi.model.SDIFacility;
import com.bombardier.rcs.mdc.sdi.model.SDISystem;
import com.bombardier.rcs.mdc.sdi.repositories.SDIDeviceRepository;
import com.bombardier.rcs.mdc.sdi.repositories.SDIDeviceTypeRepository;
import com.bombardier.rcs.mdc.sdi.repositories.SDIFacilityRepository;
import com.bombardier.rcs.mdc.sdi.repositories.SDISystemRepository;

import javax.inject.Inject;
import java.time.Instant;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Kpi Actions Service
 *
 * @author Przemyslaw Sikora
 */
public class KpiActionsService {

    @Inject
    private MongoDbActionsKpiConfigurationRepository actionsKpiConfigurationRepository;

    @Inject
    private KpiActionsRepository kpiActionsRepository;

    @Inject
    private SDIDeviceRepository deviceRepository;

    @Inject
    private SDISystemRepository systemRepository;

    @Inject
    private SDIFacilityRepository facilityRepository;

    @Inject
    private SDIDeviceTypeRepository deviceTypeRepository;

    @Inject
    private EpisodeRepository episodeRepository;

    @Inject
    private EpisodeRatioRepository episodeRatioRepository;

    @Inject
    private DataFilterHelper dataFilterHelper;

    public ActionsDataSet fetchActionsData(String kpiConfigId,
                                           String sourceId,
                                           String deviceTypeId,
                                           Long timeFrom,
                                           Long timeTo) throws EntityNotFoundException {
        KpiConfiguration kpiConfiguration = actionsKpiConfigurationRepository.findByIdentity(kpiConfigId);
        ActionsKpiConfiguration actionsKpiConfiguration = (ActionsKpiConfiguration) kpiConfiguration.getConfiguration();

        KpiActionsDataRequest request = new KpiActionsDataRequest();
        addTimeSpan(request, timeFrom, timeTo, actionsKpiConfiguration.getDefaultTimeFrame());
        addSdiObjects(request, kpiConfiguration, sourceId, deviceTypeId);
        request.setEpisodes(actionsKpiConfiguration.getEpisodes());
        request.setEpisodeGroups(actionsKpiConfiguration.getEpisodeGroups());
        addDataAggregation(request, actionsKpiConfiguration.getDataAggregation());
        request.setOutputValueType(actionsKpiConfiguration.getOutputValueType());
        request.setDataLimitation(actionsKpiConfiguration.getDataLimitation());

        Map<String, Map<String, List<OlapCellValue>>> sourceData = kpiActionsRepository.getData(request);

        return createActionsDataSet(request.getTimeFrom(), request.getTimeTo(),
                kpiConfiguration.getTitle(), actionsKpiConfiguration, sourceData);
    }

    private ActionsDataSet createActionsDataSet(ZonedDateTime timeFrom, ZonedDateTime timeTo,
                                                String title, ActionsKpiConfiguration actionsKpiConfiguration,
                                                Map<String, Map<String, List<OlapCellValue>>> sourceData)
            throws EntityNotFoundException {
        ActionsDataSet actionsDataSet = new ActionsDataSet();
        actionsDataSet.setTitle(title);
        actionsDataSet.setxAxisTitle(actionsKpiConfiguration.getxAxisTitle());
        actionsDataSet.setyAxisTitle(actionsKpiConfiguration.getyAxisTitle());
        actionsDataSet.setChartType(actionsKpiConfiguration.getChartType());
        actionsDataSet.setOutputValueType(actionsKpiConfiguration.getOutputValueType());
        actionsDataSet.setDataAggregation(actionsKpiConfiguration.getDataAggregation());

        DataAggregation dataAggregation = actionsKpiConfiguration.getDataAggregation();
        List<SourceEpisodeBaseData> data = new ArrayList<>();
        for (Map.Entry<String, Map<String, List<OlapCellValue>>> entry : sourceData.entrySet()) {
            SourceEpisodeBaseData sourceEpisodeBaseData = new SourceEpisodeBaseData();
            if (dataAggregation.getSource() != SourceAggregationType.FULL) {
                sourceEpisodeBaseData.setReference(entry.getKey());
                switch (dataAggregation.getSource()) {
                    case DEVICE:
                        sourceEpisodeBaseData.setName(deviceRepository.findByReference(entry.getKey()).getPresentationName());
                        break;

                    case SYSTEM:
                        sourceEpisodeBaseData.setName(systemRepository.findByReference(entry.getKey()).getPresentationName());
                        break;

                    case FACILITY:
                        sourceEpisodeBaseData.setName(facilityRepository.findByReference(entry.getKey()).getPresentationName());
                        break;

                    case DEVICE_TYPE:
                        sourceEpisodeBaseData.setName(deviceTypeRepository.findByReference(entry.getKey()).getDescription("en"));
                        break;

                    default:
                        break;
                }
            }
            sourceEpisodeBaseData.setEpisodes(new ArrayList<>());
            for (Map.Entry<String, List<OlapCellValue>> entry2 : entry.getValue().entrySet()) {
                EpisodeData episodeData = new EpisodeData();
                if (!dataAggregation.getEpisode()) {
                    episodeData.setReference(entry2.getKey());
                    if (actionsKpiConfiguration.getOutputValueType() == OutputValueType.RATIO) {
                        episodeData.setName(episodeRatioRepository.findByReference(entry2.getKey()).getName());
                    } else {
                        episodeData.setName(episodeRepository.findByReference(entry2.getKey()).getName());
                    }
                }
                List<OlapCellValue> d;
                if (dataAggregation.getTime()) {
                    d = entry2.getValue();
                } else {
                    d = fillTimeGaps(timeFrom, timeTo, entry2.getValue());
                }
                if (actionsKpiConfiguration.getAverageMode() == AverageMode.AVERAGE_OF_ALL) {
                    d = d.stream().map(dd -> {
                        dd.setAvgDuration(dd.getSumDuration() / dd.getCount());
                        dd.setRatio(dd.getAntecedent() / (double) dd.getConsequent());
                        return dd;
                    }).collect(Collectors.toList());
                }
                episodeData.setData(convertToData(dataAggregation.getTime(), d,
                        actionsKpiConfiguration.getOutputValueType()));
                sourceEpisodeBaseData.getEpisodes().add(episodeData);
            }
            data.add(sourceEpisodeBaseData);
        }

        actionsDataSet.setObjectSources(data);

        return actionsDataSet;
    }

    // TODO: startDate, stopDate - pełne miesiące / dni / tygodnie ?
    private List<OlapCellValue> fillTimeGaps(ZonedDateTime startDate, ZonedDateTime stopDate, List<OlapCellValue> data) {
        Map<Long, OlapCellValue> dataMap = data.stream().collect(Collectors.toMap(d -> d.getTime().toInstant().toEpochMilli(), d -> d));
        List<OlapCellValue> result = new ArrayList<>();
        TimeGranularity timeGranularity = dataFilterHelper.getBestTimeGranularity(startDate, stopDate);
        Period period = null;
        switch (timeGranularity) {
            case DAY:
                period = Period.ofDays(1);
                break;

            case WEEK:
                period = Period.ofWeeks(1);
                break;

            case MONTH:
                period = Period.ofMonths(1);
                break;

            default:
                break;
        }
        while (startDate.isBefore(stopDate)) {
            long epochTime = startDate.toInstant().toEpochMilli();
            if (dataMap.containsKey(epochTime)) {
                result.add(dataMap.get(epochTime));
            } else {
                OlapCellValue olapCellValue = new OlapCellValue();
                olapCellValue.setTime(convertToZonedDateTime(epochTime));
                result.add(olapCellValue);
            }
            startDate = startDate.plus(period);
        }
        return result;
    }

    private Double[][] convertToData(Boolean timeAggregation, List<OlapCellValue> rawData, OutputValueType outputValueType) {
        int n = 0;
        if (!timeAggregation) {
            n++;
        }
        if (outputValueType == OutputValueType.RANGE) {
            n += 3;
        } else {
            n++;
        }
        switch (outputValueType) {
            case COUNT:
                return rawData.stream().map(d ->
                        timeAggregation ?
                                new Double[]{d.getCount().doubleValue()} :
                                new Double[]{(double) d.getTime().toInstant().toEpochMilli(),
                                        d.getCount().doubleValue()}
                ).collect(Collectors.toList()).toArray(new Double[rawData.size()][n]);

            case RATIO:
                return rawData.stream().map(d ->
                        timeAggregation ?
                                new Double[]{d.getRatio()} :
                                new Double[]{(double) d.getTime().toInstant().toEpochMilli(), d.getRatio()}
                ).collect(Collectors.toList()).toArray(new Double[rawData.size()][n]);

            case MINIMUM:
                return rawData.stream().map(d ->
                        timeAggregation ?
                                new Double[]{d.getMinDuration()} :
                                new Double[]{(double) d.getTime().toInstant().toEpochMilli(), d.getMinDuration()}
                ).collect(Collectors.toList()).toArray(new Double[rawData.size()][n]);

            case MAXIMUM:
                return rawData.stream().map(d ->
                        timeAggregation ?
                                new Double[]{d.getMaxDuration()} :
                                new Double[]{(double) d.getTime().toInstant().toEpochMilli(), d.getMaxDuration()}
                ).collect(Collectors.toList()).toArray(new Double[rawData.size()][n]);

            case AVERAGE:
                return rawData.stream().map(d ->
                        timeAggregation ?
                                new Double[]{d.getAvgDuration()} :
                                new Double[]{(double) d.getTime().toInstant().toEpochMilli(), d.getAvgDuration()}
                ).collect(Collectors.toList()).toArray(new Double[rawData.size()][n]);

            case SUM:
                return rawData.stream().map(d ->
                        timeAggregation ?
                                new Double[]{d.getSumDuration()} :
                                new Double[]{(double) d.getTime().toInstant().toEpochMilli(), d.getSumDuration()}
                ).collect(Collectors.toList()).toArray(new Double[rawData.size()][n]);

            case RANGE:
                return rawData.stream().map(d ->
                        timeAggregation ?
                                new Double[]{d.getMinDuration(), d.getMaxDuration(), d.getAvgDuration()} :
                                new Double[]{(double) d.getTime().toInstant().toEpochMilli(),
                                        d.getMinDuration(), d.getMaxDuration(), d.getAvgDuration()}
                ).collect(Collectors.toList()).toArray(new Double[rawData.size()][n]);

            default:
                return new Double[0][0];
        }
    }

    private void addTimeSpan(KpiActionsDataRequest request,
                             Long timeFrom, Long timeTo, DefaultTimeFrame defaultTimeFrame) {
        if ((timeFrom != null) && (timeTo != null)) {
            request.setTimeFrom(ZonedDateTime.ofInstant(Instant.ofEpochMilli(timeFrom), ZoneId.of("UTC")));
            request.setTimeTo(ZonedDateTime.ofInstant(Instant.ofEpochMilli(timeTo), ZoneId.of("UTC")));
            return;
        }
        if (defaultTimeFrame != null) {
            if ((defaultTimeFrame.getStartTime() != null) && (defaultTimeFrame.getStopTime() != null)) {
                request.setTimeFrom(defaultTimeFrame.getStartTime());
                request.setTimeTo(defaultTimeFrame.getStopTime());
                return;
            }
            if ((defaultTimeFrame.getRelativeStartTime() != null) && defaultTimeFrame.getRelativeStopTime() != null) {
                request.setTimeFrom(ZonedDateTime.ofInstant(Instant.ofEpochMilli(
                        defaultTimeFrame.getRelativeStartTime()), ZoneId.of("UTC")));
                request.setTimeTo(ZonedDateTime.ofInstant(Instant.ofEpochMilli(
                        defaultTimeFrame.getRelativeStopTime()), ZoneId.of("UTC")));
                return;
            }
        }
        request.setTimeFrom(null);
        request.setTimeTo(null);
    }

    private void addSdiObjects(KpiActionsDataRequest request, KpiConfiguration kpiConfiguration,
                               String sourceId, String deviceTypeId) throws EntityNotFoundException {
        KpiLocationConfiguration locationConfiguration = kpiConfiguration.getLocations().get(0);
        SdiObjectPageType objectPage = locationConfiguration.getPage();
        switch (objectPage) {
            case DEVICE:
                SDIDevice device = deviceRepository.findById(sourceId);
                request.setDevices(new HashSet<>(Arrays.asList(device)));
                break;

            case SYSTEM:
            case SYSTEM_AND_DEVICE_TYPE:
                SDISystem system = systemRepository.findById(sourceId);
                request.setSystems(new HashSet<>(Arrays.asList(system)));
                break;

            case FACILITY:
            case FACILITY_AND_DEVICE_TYPE:
                SDIFacility facility = facilityRepository.findById(sourceId);
                request.setFacilities(new HashSet<>(Arrays.asList(facility)));
                break;

            default:
                break;
        }
        if ((objectPage == SdiObjectPageType.DEVICE_TYPE) || (objectPage == SdiObjectPageType.FACILITY_AND_DEVICE_TYPE)
                || (objectPage == SdiObjectPageType.SYSTEM_AND_DEVICE_TYPE)) {
            SDIDeviceType deviceType = deviceTypeRepository.findById(deviceTypeId);
            request.setDeviceTypes(new HashSet<>(Arrays.asList(deviceType)));
        }
    }

    private void addDataAggregation(KpiActionsDataRequest request, DataAggregation dataAggregation) {
        request.setSourceAggregation(dataAggregation.getSource());
        request.setEpisodeAggregation(dataAggregation.getEpisode());
        request.setTimeAggregation(dataAggregation.getTime());
    }

    private ZonedDateTime convertToZonedDateTime(long epochMilli) {
        return ZonedDateTime.ofInstant(Instant.ofEpochMilli(epochMilli), ZoneId.of("UTC"));
    }
}
