/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Time Granularity
 *
 * @author Przemyslaw Sikora
 */
public enum TimeGranularity {

    MONTH("month"), WEEK("week"), DAY("day");

    private String name;

    TimeGranularity(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    public static TimeGranularity fromString(String name) {
        for (TimeGranularity timeGranularity : TimeGranularity.values()) {
            if (timeGranularity.name.equals(name)) {
                return timeGranularity;
            }
        }
        throw new IllegalArgumentException(String.format("Unrecognized time granularity (%s)", name));
    }

}
