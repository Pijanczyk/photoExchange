/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.DataPriority;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Action Moment
 *
 * @author Przemyslaw Sikora
 */
public enum ActionMoment {

    START("start"), STOP("stop");

    private String name;

    ActionMoment(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    public static ActionMoment fromString(String name) {
        for (ActionMoment moment : ActionMoment.values()) {
            if (moment.name.equals(name)) {
                return moment;
            }
        }
        throw new IllegalArgumentException(String.format("Unrecognized action moment (%s)", name));
    }

}
