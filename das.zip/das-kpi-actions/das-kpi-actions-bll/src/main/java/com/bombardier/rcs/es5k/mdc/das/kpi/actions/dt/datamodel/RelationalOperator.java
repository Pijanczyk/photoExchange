/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Relational Operator
 *
 * @author Przemyslaw Sikora
 */
public enum RelationalOperator {

    EQUAL_TO("equalTo"), NOT_EQUAL_TO("notEqualTo"), GREATER_THAN("greaterThan"), LESS_THAN("lessThan"),
    GREATER_THAN_OR_EQUAL_TO("greaterThanOrEqualTo"), LESS_THAN_OR_EQUAL_TO("lessThanOrEqualTo");

    private String name;

    RelationalOperator(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    public static RelationalOperator fromString(String name) {
        for (RelationalOperator operator : RelationalOperator.values()) {
            if (operator.name.equals(name)) {
                return operator;
            }
        }
        throw new IllegalArgumentException(String.format("Unrecognized relational operator (%s)", name));
    }

}
