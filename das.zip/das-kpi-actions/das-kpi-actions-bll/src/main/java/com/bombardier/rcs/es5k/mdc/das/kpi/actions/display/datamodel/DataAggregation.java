/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

/**
 * Data Aggregation
 *
 * @author Przemyslaw Sikora
 */
public class DataAggregation {

    private SourceAggregationType source;
    private Boolean episode;
    private Boolean time;

    public SourceAggregationType getSource() {
        return source;
    }

    public void setSource(SourceAggregationType source) {
        this.source = source;
    }

    public Boolean getEpisode() {
        return episode;
    }

    public void setEpisode(Boolean episode) {
        this.episode = episode;
    }

    public Boolean getTime() {
        return time;
    }

    public void setTime(Boolean time) {
        this.time = time;
    }
}
