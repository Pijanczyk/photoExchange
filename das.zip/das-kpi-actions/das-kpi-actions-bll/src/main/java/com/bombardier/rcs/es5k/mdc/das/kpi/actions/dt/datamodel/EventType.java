/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

/**
 * Event Type
 *
 * @author Przemyslaw Sikora
 */
public class EventType implements Serializable {

    private String name;
    private Set<SdiEventTypePattern> patterns;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<SdiEventTypePattern> getPatterns() {
        return patterns;
    }

    public void setPatterns(Set<SdiEventTypePattern> patterns) {
        this.patterns = patterns;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EventType eventType = (EventType) o;

        if (name != null ? !name.equals(eventType.name) : eventType.name != null) return false;
        return patterns != null ? patterns.equals(eventType.patterns) : eventType.patterns == null;
    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (patterns != null ? patterns.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "EventType{" +
                "name='" + name + '\'' +
                ", patterns=" + patterns +
                '}';
    }

}
