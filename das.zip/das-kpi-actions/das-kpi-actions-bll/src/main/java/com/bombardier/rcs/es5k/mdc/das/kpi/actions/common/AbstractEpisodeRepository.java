package com.bombardier.rcs.es5k.mdc.das.kpi.actions.common;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.common.datamodel.AbstractEpisode;
import com.bombardier.rcs.mdc.exception.EntityNotFoundException;
import com.bombardier.rcs.mdc.sdi.repositories.mongodb.MongoDBRepository;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;

public abstract class AbstractEpisodeRepository<K extends String, E extends AbstractEpisode>
        extends MongoDBRepository<K, E> {

    private static final String TEXT_OBJECT_TYPE = "objectType";
    private static final String TEXT_REFERENCE = "reference";
    private static final String TEXT_NAME = "name";
    private static final String TEXT_TIMESTAMP = "timestamp";

    protected abstract String getObjectType();

    protected abstract E createNewObject();

    public AbstractEpisode findByReference(String reference) throws EntityNotFoundException {
        Bson eq1 = getAllEntitiesFilter();
        Bson eq2 = eq(TEXT_REFERENCE, reference);
        Bson and = and(eq1, eq2);
        Document doc = getManagedCollection().find(and).first();
        if (doc == null) {
            throw new EntityNotFoundException(String.format("Entity with reference %s is not found", reference));
        }
        return convertToEntity(doc);
    }

    @Override
    protected E convertToEntity(Document document) {
        E episode = createNewObject();
        episode.setId(document.getObjectId("_id").toHexString());
        episode.setReference(document.getString(TEXT_REFERENCE));
        episode.setName(document.getString(TEXT_NAME));
        episode.setTimestamp(ZonedDateTime.ofInstant(document.getDate(TEXT_TIMESTAMP).toInstant(), ZoneId.of("UTC")));
        return episode;
    }

    @Override
    protected Document convertToDocument(AbstractEpisode abstractEpisode) {
        Document document = new Document();
        document.append(TEXT_OBJECT_TYPE, getObjectType());
        document.append(TEXT_REFERENCE, abstractEpisode.getReference());
        document.append(TEXT_NAME, abstractEpisode.getName());
        document.append(TEXT_TIMESTAMP, new Date(abstractEpisode.getTimestamp().toInstant().toEpochMilli()));
        return document;
    }

    @Override
    protected String getCollectionName() {
        return Constants.EPISODE_COLLECTION_NAME;
    }

    @Override
    protected Bson getAllEntitiesFilter() {
        return eq(TEXT_OBJECT_TYPE, getObjectType());
    }
}
