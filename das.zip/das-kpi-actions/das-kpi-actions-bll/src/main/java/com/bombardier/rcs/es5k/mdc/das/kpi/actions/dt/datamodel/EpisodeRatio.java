/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel;

import java.util.Set;

/**
 * Episode Ratio
 *
 * @author Przemyslaw Sikora
 */
public class EpisodeRatio {

    private String reference;
    private String name;
    private Set<Episode> antecedent;
    private Set<Episode> consequent;

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Episode> getAntecedent() {
        return antecedent;
    }

    public void setAntecedent(Set<Episode> antecedent) {
        this.antecedent = antecedent;
    }

    public Set<Episode> getConsequent() {
        return consequent;
    }

    public void setConsequent(Set<Episode> consequent) {
        this.consequent = consequent;
    }

}
