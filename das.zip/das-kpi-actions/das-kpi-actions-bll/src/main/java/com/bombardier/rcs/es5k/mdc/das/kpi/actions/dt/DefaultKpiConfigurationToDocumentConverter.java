/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel.*;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.KpiConfigurationToDocumentConverter;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel.SpecificKpiConfiguration;
import org.bson.Document;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Specific Kpi Configuration Converter
 *
 * @author Przemyslaw Sikora
 */
@Stateless
@Remote(KpiConfigurationToDocumentConverter.class)
public class DefaultKpiConfigurationToDocumentConverter implements KpiConfigurationToDocumentConverter {

    private static final String TEXT_DATA_FILTER = "dataFilter";
    private static final String TEXT_DEVICES = "devices";
    private static final String TEXT_SYSTEMS = "systems";
    private static final String TEXT_FACILITIES = "facilities";
    private static final String TEXT_DEVICE_TYPES = "deviceTypes";
    private static final String TEXT_REFERENCES = "references";
    private static final String TEXT_SEVERITIES = "severities";
    private static final String TEXT_STATES = "states";
    private static final String TEXT_PATTERNS = "patterns";
    private static final String TEXT_EVENT_TYPES = "eventTypes";
    private static final String TEXT_NAME = "name";
    private static final String TEXT_EPISODES = "episodes";
    private static final String TEXT_REFERENCE = "reference";
    private static final String TEXT_GROUP_REFERENCE = "groupReference";
    private static final String TEXT_FILTERS = "filters";
    private static final String TEXT_MIN_DURATION = "minDuration";
    private static final String TEXT_MAX_DURATION = "maxDuration";
    private static final String TEXT_MEASUREMENT_CONDITIONS = "measurementConditions";
    private static final String TEXT_ACTION_MOMENT = "actionMoment";
    private static final String TEXT_BASE_SOURCE = "baseSource";
    private static final String TEXT_TARGET_SOURCE = "targetSource";
    private static final String TEXT_SOURCE_MAPPING_FUNCTION = "sourceMappingFunction";
    private static final String TEXT_ATTRIBUTE = "attribute";
    private static final String TEXT_OPERATOR = "operator";
    private static final String TEXT_VALUE = "value";
    private static final String TEXT_EPISODE_RATIOS = "episodeRatios";
    private static final String TEXT_ANTECEDENT = "antecedent";
    private static final String TEXT_CONSEQUENT = "consequent";

    @SuppressWarnings("unchecked")
    @Override
    public SpecificKpiConfiguration convertToKpiConfiguration(Document document) {
        ActionsKpiConfiguration configuration = new ActionsKpiConfiguration();
        if (document.containsKey(TEXT_DATA_FILTER)) {
            configuration.setDataFilters(((List<Document>) document.get(TEXT_DATA_FILTER, List.class)).stream()
                    .map(this::convertToDataFilter).collect(Collectors.toSet()));
        }
        configuration.setEventTypes(((List<Document>) document.get(TEXT_EVENT_TYPES, List.class)).stream()
                .map(this::convertToEventType).collect(Collectors.toSet()));
        Map<String, EventType> eventTypeMap = new HashMap<>();
        for (EventType eventType : configuration.getEventTypes()) {
            eventTypeMap.put(eventType.getName(), eventType);
        }
        configuration.setEpisodes(((List<Document>) document.get(TEXT_EPISODES, List.class)).stream()
                .map((doc -> convertToEpisode(doc, eventTypeMap))).collect(Collectors.toSet()));
        Map<String, Episode> episodeMap = new HashMap<>();
        for (Episode episode : configuration.getEpisodes()) {
            episodeMap.put(episode.getReference(), episode);
        }
        if (document.containsKey(TEXT_EPISODE_RATIOS)) {
            configuration.setEpisodeRatios(((List<Document>) document.get(TEXT_EPISODE_RATIOS, List.class)).stream()
                    .map(doc -> convertToEpisodeRatio(doc, episodeMap)).collect(Collectors.toSet()));
        }
        return configuration;
    }

    @Override
    public Document convertToDocument(SpecificKpiConfiguration configuration) {
        if (!(configuration instanceof ActionsKpiConfiguration)) {
            throw new IllegalArgumentException(
                    "Actions DefaultKpiConfigurationToDocumentConverter requires ActionsKpiConfiguration as an input configuration");
        }
        ActionsKpiConfiguration config = (ActionsKpiConfiguration) configuration;
        Document document = new Document();
        if (!isNullOrEmpty(config.getDataFilters())) {
            document.append(TEXT_DATA_FILTER, config.getDataFilters().stream().filter(Objects::nonNull)
                    .map(this::convertToDataFilterDocument).collect(Collectors.toList()));
        }
        document.append(TEXT_EVENT_TYPES, config.getEventTypes().stream().filter(Objects::nonNull)
                .map(this::convertToEventTypeDocument).collect(Collectors.toList()));
        document.append(TEXT_EPISODES, config.getEpisodes().stream().filter(Objects::nonNull)
                .map(this::convertToEpisodeDocument).collect(Collectors.toList()));
        if (!isNullOrEmpty(config.getEpisodeRatios())) {
            document.append(TEXT_EPISODE_RATIOS, config.getEpisodeRatios().stream().filter(Objects::nonNull)
                    .map(this::convertToEpisodeRatioDocument).collect(Collectors.toList()));
        }
        return document;
    }

    @SuppressWarnings("unchecked")
    private DataFilter convertToDataFilter(Document document) {
        DataFilter dataFilter = new DataFilter();
        if (document.containsKey(TEXT_DEVICES)) {
            dataFilter.setDevices(((List<Document>) document.get(TEXT_DEVICES, List.class))
                    .stream().map(this::convertToObjectFilter).collect(Collectors.toSet()));
        }
        if (document.containsKey(TEXT_SYSTEMS)) {
            dataFilter.setSystems(((List<Document>) document.get(TEXT_SYSTEMS, List.class))
                    .stream().map(this::convertToObjectFilter).collect(Collectors.toSet()));
        }
        if (document.containsKey(TEXT_FACILITIES)) {
            dataFilter.setFacilities(((List<Document>) document.get(TEXT_FACILITIES, List.class))
                    .stream().map(this::convertToObjectFilter).collect(Collectors.toSet()));
        }
        if (document.containsKey(TEXT_DEVICE_TYPES)) {
            dataFilter.setDeviceTypes(((List<Document>) document.get(TEXT_DEVICE_TYPES, List.class))
                    .stream().map(this::convertToObjectFilter).collect(Collectors.toSet()));
        }
        return dataFilter;
    }

    @SuppressWarnings("unchecked")
    private EventType convertToEventType(Document document) {
        EventType eventType = new EventType();
        eventType.setName(document.getString(TEXT_NAME));
        eventType.setPatterns(((List<Document>) document.get(TEXT_PATTERNS, List.class))
                .stream().map(this::convertToSdiEventTypePattern).collect(Collectors.toSet()));
        return eventType;
    }

    @SuppressWarnings("unchecked")
    private SdiEventTypePattern convertToSdiEventTypePattern(Document document) {
        SdiEventTypePattern pattern = new SdiEventTypePattern();
        if (document.containsKey(TEXT_REFERENCES)) {
            pattern.setReferences(((List<Document>) document.get(TEXT_REFERENCES, List.class))
                    .stream().map(this::convertToObjectFilter).collect(Collectors.toSet()));
        }
        if (document.containsKey(TEXT_SEVERITIES)) {
            pattern.setSeverities(new HashSet<>((List<String>) document.get(TEXT_SEVERITIES, List.class)));
        }
        if (document.containsKey(TEXT_STATES)) {
            pattern.setStates(new HashSet<>((List<String>) document.get(TEXT_STATES, List.class)));
        }
        return pattern;
    }

    @SuppressWarnings("unchecked")
    private Episode convertToEpisode(Document document, Map<String, EventType> eventTypeMap) {
        Episode episode = new Episode();
        episode.setReference(document.getString(TEXT_REFERENCE));
        if (document.containsKey(TEXT_GROUP_REFERENCE)) {
            episode.setGroupReference(document.getString(TEXT_GROUP_REFERENCE));
        }
        episode.setName(document.getString(TEXT_NAME));
        episode.setEventTypes(((List<String>) document.get(TEXT_EVENT_TYPES, List.class))
                .stream().map(eventTypeMap::get).collect(Collectors.toList()));
        if (document.containsKey(TEXT_FILTERS)) {
            episode.setFilter(convertToEpisodeFilter(document.get(TEXT_FILTERS, Document.class)));
        }
        return episode;
    }

    @SuppressWarnings("unchecked")
    private EpisodeFilter convertToEpisodeFilter(Document document) {
        EpisodeFilter episodeFilter = new EpisodeFilter();
        if (document.containsKey(TEXT_MIN_DURATION)) {
            episodeFilter.setMinimumDuration(Duration.parse(document.getString(TEXT_MIN_DURATION)));
        }
        if (document.containsKey(TEXT_MAX_DURATION)) {
            episodeFilter.setMaximumDuration(Duration.parse(document.getString(TEXT_MAX_DURATION)));
        }
        if (document.containsKey(TEXT_MEASUREMENT_CONDITIONS)) {
            episodeFilter.setMeasurementConditions(
                    ((List<Document>) document.get(TEXT_MEASUREMENT_CONDITIONS, List.class)).stream()
                            .map(this::convertToMeasurementCondition).collect(Collectors.toSet()));
        }
        return episodeFilter;
    }

    private MeasurementCondition convertToMeasurementCondition(Document document) {
        MeasurementCondition measurementCondition = new MeasurementCondition();
        if (document.containsKey(TEXT_ACTION_MOMENT)) {
            measurementCondition.setActionMoment(ActionMoment.fromString(document.getString(TEXT_ACTION_MOMENT)));
        }
        if (document.containsKey(TEXT_BASE_SOURCE)) {
            measurementCondition.setBaseSourceReference(document.getString(TEXT_BASE_SOURCE));
        }
        if (document.containsKey(TEXT_TARGET_SOURCE)) {
            measurementCondition.setTargetSourceReference(document.getString(TEXT_TARGET_SOURCE));
        }
        if (document.containsKey(TEXT_SOURCE_MAPPING_FUNCTION)) {
            measurementCondition.setSourceMappingFunction(document.getString(TEXT_SOURCE_MAPPING_FUNCTION));
        }
        measurementCondition.setAttribute(document.getString(TEXT_ATTRIBUTE));
        measurementCondition.setOperator(RelationalOperator.fromString(document.getString(TEXT_OPERATOR)));
        measurementCondition.setValue(document.getString(TEXT_VALUE));
        return measurementCondition;
    }

    @SuppressWarnings("unchecked")
    private EpisodeRatio convertToEpisodeRatio(Document document, Map<String, Episode> episodeMap) {
        EpisodeRatio episodeRatio = new EpisodeRatio();
        episodeRatio.setReference(document.getString(TEXT_REFERENCE));
        episodeRatio.setName(document.getString(TEXT_NAME));
        episodeRatio.setAntecedent(((List<String>) document.get(TEXT_ANTECEDENT, List.class))
                .stream().map(episodeMap::get).collect(Collectors.toSet()));
        episodeRatio.setConsequent(((List<String>) document.get(TEXT_CONSEQUENT, List.class))
                .stream().map(episodeMap::get).collect(Collectors.toSet()));
        return episodeRatio;
    }

    @SuppressWarnings("unchecked")
    private ObjectFilter convertToObjectFilter(Document document) {
        ObjectFilter objectFilter = new ObjectFilter();
        if (document.containsKey(TEXT_REFERENCES)) {
            objectFilter.setReferences(new HashSet<>((List<String>) document.get(TEXT_REFERENCES, List.class)));
        }
        if (document.containsKey(TEXT_PATTERNS)) {
            objectFilter.setPatterns(new HashSet<>((List<String>) document.get(TEXT_PATTERNS, List.class)));
        }
        return objectFilter;
    }

    private Document convertToEpisodeDocument(Episode episode) {
        Document document = new Document();
        document.append(TEXT_REFERENCE, episode.getReference());
        if (episode.getGroupReference() != null) {
            document.append(TEXT_GROUP_REFERENCE, episode.getGroupReference());
        }
        document.append(TEXT_NAME, episode.getName());
        document.append(TEXT_EVENT_TYPES, episode.getEventTypes().stream()
                .map(EventType::getName).collect(Collectors.toList()));
        if (episode.getFilter() != null) {
            document.append(TEXT_FILTERS, convertToEpisodeFilterDocument(episode.getFilter()));
        }
        return document;
    }

    private Document convertToEpisodeFilterDocument(EpisodeFilter episodeFilter) {
        Document document = new Document();
        if (episodeFilter.getMinimumDuration() != null) {
            document.append(TEXT_MIN_DURATION, episodeFilter.getMinimumDuration().toString());
        }
        if (episodeFilter.getMaximumDuration() != null) {
            document.append(TEXT_MAX_DURATION, episodeFilter.getMaximumDuration().toString());
        }
        if (!isNullOrEmpty(episodeFilter.getMeasurementConditions())) {
            document.append(TEXT_MEASUREMENT_CONDITIONS, episodeFilter.getMeasurementConditions()
                    .stream().filter(Objects::nonNull)
                    .map(this::convertToMeasurementConditionDocument).collect(Collectors.toList()));
        }
        return document;
    }

    private Document convertToMeasurementConditionDocument(MeasurementCondition measurementCondition) {
        Document document = new Document();
        document.append(TEXT_ACTION_MOMENT, Optional.ofNullable(measurementCondition.getActionMoment())
                .orElse(ActionMoment.START).getName());
        if (measurementCondition.getBaseSourceReference() != null) {
            document.append(TEXT_BASE_SOURCE, measurementCondition.getBaseSourceReference());
        }
        if (measurementCondition.getTargetSourceReference() != null) {
            document.append(TEXT_TARGET_SOURCE, measurementCondition.getTargetSourceReference());
        }
        if (measurementCondition.getSourceMappingFunction() != null) {
            document.append(TEXT_SOURCE_MAPPING_FUNCTION, measurementCondition.getSourceMappingFunction());
        }
        document.append(TEXT_ATTRIBUTE, measurementCondition.getAttribute());
        document.append(TEXT_OPERATOR, measurementCondition.getOperator().getName());
        document.append(TEXT_VALUE, measurementCondition.getValue());
        return document;
    }

    private Document convertToEventTypeDocument(EventType eventType) {
        Document document = new Document();
        document.append(TEXT_NAME, eventType.getName());
        document.append(TEXT_PATTERNS, eventType.getPatterns().stream().filter(Objects::nonNull)
                .map(this::convertToSdiEventTypePatternDocument).collect(Collectors.toList()));
        return document;
    }

    private Document convertToSdiEventTypePatternDocument(SdiEventTypePattern pattern) {
        Document document = new Document();
        if (!isNullOrEmpty(pattern.getReferences())) {
            document.append(TEXT_REFERENCES, pattern.getReferences().stream()
                    .map(this::convertToObjectFilterDocument).collect(Collectors.toList()));
        }
        if (!isNullOrEmpty(pattern.getSeverities())) {
            document.append(TEXT_SEVERITIES, pattern.getSeverities());
        }
        if (!isNullOrEmpty(pattern.getStates())) {
            document.append(TEXT_STATES, pattern.getStates());
        }
        return document;
    }

    private Document convertToDataFilterDocument(DataFilter dataFilter) {
        Document document = new Document();
        if (!isNullOrEmpty(dataFilter.getDevices())) {
            document.append(TEXT_DEVICES, dataFilter.getDevices().stream().filter(Objects::nonNull)
                    .map(this::convertToObjectFilterDocument).collect(Collectors.toList()));
        }
        if (!isNullOrEmpty(dataFilter.getSystems())) {
            document.append(TEXT_SYSTEMS, dataFilter.getSystems().stream().filter(Objects::nonNull)
                    .map(this::convertToObjectFilterDocument).collect(Collectors.toList()));
        }
        if (!isNullOrEmpty(dataFilter.getFacilities())) {
            document.append(TEXT_FACILITIES, dataFilter.getFacilities().stream().filter(Objects::nonNull)
                    .map(this::convertToObjectFilterDocument).collect(Collectors.toList()));
        }
        if (!isNullOrEmpty(dataFilter.getDeviceTypes())) {
            document.append(TEXT_DEVICE_TYPES, dataFilter.getDeviceTypes().stream().filter(Objects::nonNull)
                    .map(this::convertToObjectFilterDocument).collect(Collectors.toList()));
        }
        return document;
    }

    private Document convertToObjectFilterDocument(ObjectFilter objectFilter) {
        Document document = new Document();
        if (objectFilter.getReferences() != null) {
            document.append(TEXT_REFERENCES, objectFilter.getReferences());
        }
        if (objectFilter.getPatterns() != null) {
            document.append(TEXT_PATTERNS, objectFilter.getPatterns());
        }
        return document;
    }

    private Document convertToEpisodeRatioDocument(EpisodeRatio episodeRatio) {
        Document document = new Document();
        document.append(TEXT_REFERENCE, episodeRatio.getReference());
        document.append(TEXT_NAME, episodeRatio.getName());
        document.append(TEXT_ANTECEDENT, episodeRatio.getAntecedent().stream()
                .filter(Objects::nonNull).map(Episode::getReference).collect(Collectors.toList()));
        document.append(TEXT_CONSEQUENT, episodeRatio.getConsequent().stream()
                .filter(Objects::nonNull).map(Episode::getReference).collect(Collectors.toList()));
        return document;
    }

    private Boolean isNullOrEmpty(Collection<?> list) {
        return list == null || list.isEmpty();
    }

}
