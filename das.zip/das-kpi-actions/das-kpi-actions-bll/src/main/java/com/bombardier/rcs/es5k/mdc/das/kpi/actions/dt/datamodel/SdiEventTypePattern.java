/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel;

import java.io.Serializable;
import java.util.Set;

/**
 * Sdi Event Type Pattern
 *
 * @author Przemyslaw Sikora
 */
public class SdiEventTypePattern implements Serializable {

    private Set<ObjectFilter> references;
    private Set<String> severities;
    private Set<String> states;

    public Set<ObjectFilter> getReferences() {
        return references;
    }

    public void setReferences(Set<ObjectFilter> references) {
        this.references = references;
    }

    public Set<String> getSeverities() {
        return severities;
    }

    public void setSeverities(Set<String> severities) {
        this.severities = severities;
    }

    public Set<String> getStates() {
        return states;
    }

    public void setStates(Set<String> states) {
        this.states = states;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SdiEventTypePattern pattern = (SdiEventTypePattern) o;

        if (references != null ? !references.equals(pattern.references) : pattern.references != null) return false;
        if (severities != null ? !severities.equals(pattern.severities) : pattern.severities != null) return false;
        return states != null ? states.equals(pattern.states) : pattern.states == null;
    }

    @Override
    public int hashCode() {
        int result = references != null ? references.hashCode() : 0;
        result = 31 * result + (severities != null ? severities.hashCode() : 0);
        result = 31 * result + (states != null ? states.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SdiEventTypePattern{" +
                "references=" + references +
                ", severities=" + severities +
                ", states=" + states +
                '}';
    }

}
