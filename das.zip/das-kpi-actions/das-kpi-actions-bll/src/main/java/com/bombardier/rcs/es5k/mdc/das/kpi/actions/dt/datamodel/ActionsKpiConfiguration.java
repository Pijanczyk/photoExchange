/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel;

import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel.SpecificKpiConfiguration;

import java.util.Set;

/**
 * Actions Kpi Configuration
 *
 * @author Przemyslaw Sikora
 */
public class ActionsKpiConfiguration implements SpecificKpiConfiguration {

    private Set<DataFilter> dataFilters;
    private Set<EventType> eventTypes;
    private Set<Episode> episodes;
    private Set<EpisodeRatio> episodeRatios;

    public Set<DataFilter> getDataFilters() {
        return dataFilters;
    }

    public void setDataFilters(Set<DataFilter> dataFilters) {
        this.dataFilters = dataFilters;
    }

    public Set<EventType> getEventTypes() {
        return eventTypes;
    }

    public void setEventTypes(Set<EventType> eventTypes) {
        this.eventTypes = eventTypes;
    }

    public Set<Episode> getEpisodes() {
        return episodes;
    }

    public void setEpisodes(Set<Episode> episodes) {
        this.episodes = episodes;
    }

    public Set<EpisodeRatio> getEpisodeRatios() {
        return episodeRatios;
    }

    public void setEpisodeRatios(Set<EpisodeRatio> episodeRatios) {
        this.episodeRatios = episodeRatios;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ActionsKpiConfiguration that = (ActionsKpiConfiguration) o;

        if (dataFilters != null ? !dataFilters.equals(that.dataFilters) : that.dataFilters != null) return false;
        if (eventTypes != null ? !eventTypes.equals(that.eventTypes) : that.eventTypes != null) return false;
        if (episodes != null ? !episodes.equals(that.episodes) : that.episodes != null) return false;
        return episodeRatios != null ? episodeRatios.equals(that.episodeRatios) : that.episodeRatios == null;
    }

    @Override
    public int hashCode() {
        int result = dataFilters != null ? dataFilters.hashCode() : 0;
        result = 31 * result + (eventTypes != null ? eventTypes.hashCode() : 0);
        result = 31 * result + (episodes != null ? episodes.hashCode() : 0);
        result = 31 * result + (episodeRatios != null ? episodeRatios.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ActionsKpiConfiguration{" +
                "dataFilters=" + dataFilters +
                ", eventTypes=" + eventTypes +
                ", episodes=" + episodes +
                ", episodeRatios=" + episodeRatios +
                '}';
    }
}
