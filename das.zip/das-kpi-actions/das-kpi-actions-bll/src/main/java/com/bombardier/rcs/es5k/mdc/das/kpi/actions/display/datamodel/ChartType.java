/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Chart Type
 *
 * @author Przemyslaw Sikora
 */
public enum ChartType {

    LINE("line"), COLUMN("column"), HEATMAP("heatmap");

    private String name;

    ChartType(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    public static ChartType fromString(String name) {
        for (ChartType chartType : ChartType.values()) {
            if (chartType.name.equals(name)) {
                return chartType;
            }
        }
        throw new IllegalArgumentException(String.format("Unrecognized chart type (%s)", name));
    }

}
