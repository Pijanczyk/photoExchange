/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.common;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.common.datamodel.EpisodeRatio;

/**
 * Episode Ratio Repository
 *
 * @author Przemyslaw Sikora
 */
public class EpisodeRatioRepository extends AbstractEpisodeRepository<String, EpisodeRatio> {

    protected static final String TEXT_EPISODE_RATIO = "episodeRatio";

    @Override
    protected String getObjectType() {
        return TEXT_EPISODE_RATIO;
    }

    @Override
    protected EpisodeRatio createNewObject() {
        return new EpisodeRatio();
    }

}
