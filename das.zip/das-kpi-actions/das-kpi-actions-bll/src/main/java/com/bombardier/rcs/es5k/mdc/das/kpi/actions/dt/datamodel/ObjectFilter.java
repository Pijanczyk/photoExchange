/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel;

import java.io.Serializable;
import java.util.Set;

/**
 * Object Filter
 *
 * @author Przemyslaw Sikora
 */
public class ObjectFilter implements Serializable {

    private Set<String> references;
    private Set<String> patterns;

    public Set<String> getReferences() {
        return references;
    }

    public void setReferences(Set<String> references) {
        this.references = references;
    }

    public Set<String> getPatterns() {
        return patterns;
    }

    public void setPatterns(Set<String> patterns) {
        this.patterns = patterns;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ObjectFilter that = (ObjectFilter) o;

        if (references != null ? !references.equals(that.references) : that.references != null) return false;
        return patterns != null ? patterns.equals(that.patterns) : that.patterns == null;
    }

    @Override
    public int hashCode() {
        int result = references != null ? references.hashCode() : 0;
        result = 31 * result + (patterns != null ? patterns.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ObjectFilter{" +
                "references=" + references +
                ", patterns=" + patterns +
                '}';
    }

}
