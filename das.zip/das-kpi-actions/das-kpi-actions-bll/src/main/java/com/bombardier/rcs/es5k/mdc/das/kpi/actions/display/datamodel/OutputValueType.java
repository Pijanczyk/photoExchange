/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Output Value Type
 *
 * @author Przemyslaw Sikora
 */
public enum OutputValueType {

    COUNT("count"), MINIMUM("min"), MAXIMUM("max"),
    AVERAGE("avg"), SUM("sum"), RANGE("range"), RATIO("ratio");

    private String name;

    OutputValueType(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    public static OutputValueType fromString(String name) {
        for (OutputValueType outputValueType : OutputValueType.values()) {
            if (outputValueType.name.equals(name)) {
                return outputValueType;
            }
        }
        throw new IllegalArgumentException(String.format("Unrecognized output value type (%s)", name));
    }

}
