/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Target Property
 *
 * @author Przemyslaw Sikora
 */
public enum TargetProperty {

    MINIMUM("min"), MAXIMUM("max");

    private String name;

    TargetProperty(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    public static TargetProperty fromString(String name) {
        for (TargetProperty targetProperty : TargetProperty.values()) {
            if (targetProperty.name.equals(name)) {
                return targetProperty;
            }
        }
        throw new IllegalArgumentException(String.format("Unrecognized target property (%s)", name));
    }

}
