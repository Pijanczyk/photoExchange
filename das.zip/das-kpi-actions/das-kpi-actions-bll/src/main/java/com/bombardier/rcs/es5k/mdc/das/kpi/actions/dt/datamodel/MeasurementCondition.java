/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel;

import java.io.Serializable;

/**
 * Measurement Condition
 *
 * @author Przemyslaw Sikora
 */
public class MeasurementCondition implements Serializable {

    private ActionMoment actionMoment;
    private String baseSourceReference;
    private String targetSourceReference;
    private String sourceMappingFunction;
    private String attribute;
    private RelationalOperator operator;
    private String value;

    public ActionMoment getActionMoment() {
        return actionMoment;
    }

    public void setActionMoment(ActionMoment actionMoment) {
        this.actionMoment = actionMoment;
    }

    public String getBaseSourceReference() {
        return baseSourceReference;
    }

    public void setBaseSourceReference(String baseSourceReference) {
        this.baseSourceReference = baseSourceReference;
    }

    public String getTargetSourceReference() {
        return targetSourceReference;
    }

    public void setTargetSourceReference(String targetSourceReference) {
        this.targetSourceReference = targetSourceReference;
    }

    public String getSourceMappingFunction() {
        return sourceMappingFunction;
    }

    public void setSourceMappingFunction(String sourceMappingFunction) {
        this.sourceMappingFunction = sourceMappingFunction;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public RelationalOperator getOperator() {
        return operator;
    }

    public void setOperator(RelationalOperator operator) {
        this.operator = operator;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MeasurementCondition that = (MeasurementCondition) o;

        if (actionMoment != that.actionMoment) return false;
        if (baseSourceReference != null ? !baseSourceReference.equals(that.baseSourceReference) : that.baseSourceReference != null)
            return false;
        if (targetSourceReference != null ? !targetSourceReference.equals(that.targetSourceReference) : that.targetSourceReference != null)
            return false;
        if (sourceMappingFunction != null ? !sourceMappingFunction.equals(that.sourceMappingFunction) : that.sourceMappingFunction != null)
            return false;
        if (attribute != null ? !attribute.equals(that.attribute) : that.attribute != null) return false;
        if (operator != that.operator) return false;
        return value != null ? value.equals(that.value) : that.value == null;
    }

    @Override
    public int hashCode() {
        int result = actionMoment != null ? actionMoment.hashCode() : 0;
        result = 31 * result + (baseSourceReference != null ? baseSourceReference.hashCode() : 0);
        result = 31 * result + (targetSourceReference != null ? targetSourceReference.hashCode() : 0);
        result = 31 * result + (sourceMappingFunction != null ? sourceMappingFunction.hashCode() : 0);
        result = 31 * result + (attribute != null ? attribute.hashCode() : 0);
        result = 31 * result + (operator != null ? operator.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "MeasurementCondition{" +
                "actionMoment=" + actionMoment +
                ", baseSourceReference='" + baseSourceReference + '\'' +
                ", targetSourceReference='" + targetSourceReference + '\'' +
                ", sourceMappingFunction='" + sourceMappingFunction + '\'' +
                ", attribute='" + attribute + '\'' +
                ", operator=" + operator +
                ", value='" + value + '\'' +
                '}';
    }
}
