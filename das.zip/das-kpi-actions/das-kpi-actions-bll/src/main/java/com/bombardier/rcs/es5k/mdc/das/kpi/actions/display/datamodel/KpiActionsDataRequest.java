/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.DataLimitation;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.OutputValueType;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.SourceAggregationType;
import com.bombardier.rcs.mdc.sdi.model.SDIDevice;
import com.bombardier.rcs.mdc.sdi.model.SDIDeviceType;
import com.bombardier.rcs.mdc.sdi.model.SDIFacility;
import com.bombardier.rcs.mdc.sdi.model.SDISystem;

import java.time.ZonedDateTime;
import java.util.Set;

/**
 * Kpi Actions Data Request
 *
 * @author Przemyslaw Sikora
 */
public class KpiActionsDataRequest {

    /**
     * Time filter
     */
    private ZonedDateTime timeFrom;
    private ZonedDateTime timeTo;

    /**
     * Source filter
     */
    private Set<SDIFacility> facilities;
    private Set<SDISystem> systems;
    private Set<SDIDevice> devices;
    private Set<SDIDeviceType> deviceTypes;

    /**
     * Episode filter
     */
    private Set<String> episodes;
    private Set<String> episodeGroups;

    /**
     * Output value type
     */
    private OutputValueType outputValueType;

    /**
     * Aggregation types
     */
    private SourceAggregationType sourceAggregation;
    private Boolean episodeAggregation;
    private Boolean timeAggregation;

    /**
     * Parameters
     */
    private DataLimitation dataLimitation;


    public ZonedDateTime getTimeFrom() {
        return timeFrom;
    }

    public void setTimeFrom(ZonedDateTime timeFrom) {
        this.timeFrom = timeFrom;
    }

    public ZonedDateTime getTimeTo() {
        return timeTo;
    }

    public void setTimeTo(ZonedDateTime timeTo) {
        this.timeTo = timeTo;
    }

    public Set<SDIFacility> getFacilities() {
        return facilities;
    }

    public void setFacilities(Set<SDIFacility> facilities) {
        this.facilities = facilities;
    }

    public Set<SDISystem> getSystems() {
        return systems;
    }

    public void setSystems(Set<SDISystem> systems) {
        this.systems = systems;
    }

    public Set<SDIDevice> getDevices() {
        return devices;
    }

    public void setDevices(Set<SDIDevice> devices) {
        this.devices = devices;
    }

    public Set<SDIDeviceType> getDeviceTypes() {
        return deviceTypes;
    }

    public void setDeviceTypes(Set<SDIDeviceType> deviceTypes) {
        this.deviceTypes = deviceTypes;
    }

    public Set<String> getEpisodes() {
        return episodes;
    }

    public void setEpisodes(Set<String> episodes) {
        this.episodes = episodes;
    }

    public Set<String> getEpisodeGroups() {
        return episodeGroups;
    }

    public void setEpisodeGroups(Set<String> episodeGroups) {
        this.episodeGroups = episodeGroups;
    }

    public OutputValueType getOutputValueType() {
        return outputValueType;
    }

    public void setOutputValueType(OutputValueType outputValueType) {
        this.outputValueType = outputValueType;
    }

    public SourceAggregationType getSourceAggregation() {
        return sourceAggregation;
    }

    public void setSourceAggregation(SourceAggregationType sourceAggregation) {
        this.sourceAggregation = sourceAggregation;
    }

    public Boolean getEpisodeAggregation() {
        return episodeAggregation;
    }

    public void setEpisodeAggregation(Boolean episodeAggregation) {
        this.episodeAggregation = episodeAggregation;
    }

    public Boolean getTimeAggregation() {
        return timeAggregation;
    }

    public void setTimeAggregation(Boolean timeAggregation) {
        this.timeAggregation = timeAggregation;
    }

    public DataLimitation getDataLimitation() {
        return dataLimitation;
    }

    public void setDataLimitation(DataLimitation dataLimitation) {
        this.dataLimitation = dataLimitation;
    }
}
