/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Source Aggregation Type
 *
 * @author Przemyslaw Sikora
 */
public enum SourceAggregationType {

    FACILITY("facility"), SYSTEM("system"), DEVICE("device"),
    DEVICE_TYPE("deviceType"), FULL("full");

    private String name;

    SourceAggregationType(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    public static SourceAggregationType fromString(String name) {
        for (SourceAggregationType type : SourceAggregationType.values()) {
            if (type.name.equals(name)) {
                return type;
            }
        }
        throw new IllegalArgumentException(String.format("Unrecognized source aggregation type (%s)", name));
    }

}
