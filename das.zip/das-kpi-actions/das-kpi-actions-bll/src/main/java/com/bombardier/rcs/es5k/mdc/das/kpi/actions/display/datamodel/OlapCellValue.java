/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import java.time.ZonedDateTime;

/**
 * Olap Cell Value
 *
 * @author Przemyslaw Sikora
 */
public class OlapCellValue {

    private String sourceReference;
    private String episodeReference;
    private ZonedDateTime time;

    private Long count;
    private Double minDuration;
    private Double maxDuration;
    private Double avgDuration;
    private Double sumDuration;
    private Double ratio;
    private Long antecedent;
    private Long consequent;

    public OlapCellValue() {
        count = 0L;
        minDuration = 0.0;
        maxDuration = 0.0;
        avgDuration = 0.0;
        sumDuration = 0.0;
        ratio = 0.0;
        antecedent = 0L;
        consequent = 0L;
    }

    public String getSourceReference() {
        return sourceReference;
    }

    public void setSourceReference(String sourceReference) {
        this.sourceReference = sourceReference;
    }

    public String getEpisodeReference() {
        return episodeReference;
    }

    public void setEpisodeReference(String episodeReference) {
        this.episodeReference = episodeReference;
    }

    public ZonedDateTime getTime() {
        return time;
    }

    public void setTime(ZonedDateTime time) {
        this.time = time;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    public Double getMinDuration() {
        return minDuration;
    }

    public void setMinDuration(Double minDuration) {
        this.minDuration = minDuration;
    }

    public Double getMaxDuration() {
        return maxDuration;
    }

    public void setMaxDuration(Double maxDuration) {
        this.maxDuration = maxDuration;
    }

    public Double getAvgDuration() {
        return avgDuration;
    }

    public void setAvgDuration(Double avgDuration) {
        this.avgDuration = avgDuration;
    }

    public Double getSumDuration() {
        return sumDuration;
    }

    public void setSumDuration(Double sumDuration) {
        this.sumDuration = sumDuration;
    }

    public Double getRatio() {
        return ratio;
    }

    public void setRatio(Double ratio) {
        this.ratio = ratio;
    }

    public Long getAntecedent() {
        return antecedent;
    }

    public void setAntecedent(Long antecedent) {
        this.antecedent = antecedent;
    }

    public Long getConsequent() {
        return consequent;
    }

    public void setConsequent(Long consequent) {
        this.consequent = consequent;
    }
}
