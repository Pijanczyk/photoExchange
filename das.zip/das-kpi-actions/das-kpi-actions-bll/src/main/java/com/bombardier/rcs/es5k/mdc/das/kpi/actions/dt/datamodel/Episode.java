/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel;

import java.io.Serializable;
import java.util.List;

/**
 * Episode
 *
 * @author Przemyslaw Sikora
 */
public class Episode implements Serializable {

    private String reference;
    private String groupReference;
    private String name;
    private List<EventType> eventTypes;
    private EpisodeFilter filter;

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getGroupReference() {
        return groupReference;
    }

    public void setGroupReference(String groupReference) {
        this.groupReference = groupReference;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<EventType> getEventTypes() {
        return eventTypes;
    }

    public void setEventTypes(List<EventType> eventTypes) {
        this.eventTypes = eventTypes;
    }

    public EpisodeFilter getFilter() {
        return filter;
    }

    public void setFilter(EpisodeFilter filter) {
        this.filter = filter;
    }

}
