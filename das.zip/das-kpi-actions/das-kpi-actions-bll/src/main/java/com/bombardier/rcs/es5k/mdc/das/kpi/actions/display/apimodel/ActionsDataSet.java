/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.apimodel;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.ChartType;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.DataAggregation;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.OutputValueType;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Actions Data Set
 *
 * @author Przemyslaw Sikora
 */
public class ActionsDataSet {

    /**
     * Title of the KPI
     */
    @NotNull
    private String title;

    /**
     * Type of chart
     */
    @NotNull
    private ChartType chartType;

    /**
     * Title of X axis
     */
    @NotNull
    private String xAxisTitle;

    /**
     * Title of Y axis
     */
    @NotNull
    private String yAxisTitle;

    /**
     * Indicates what is the value of data series
     */
    @NotNull
    private OutputValueType outputValueType;

    /**
     * Data summarization rules
     */
    @NotNull
    private DataAggregation dataAggregation;

    /**
     * Data series grouped by source object, episodes, time
     */
    @NotNull
    private List<SourceEpisodeBaseData> objectSources;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ChartType getChartType() {
        return chartType;
    }

    public void setChartType(ChartType chartType) {
        this.chartType = chartType;
    }

    public String getxAxisTitle() {
        return xAxisTitle;
    }

    public void setxAxisTitle(String xAxisTitle) {
        this.xAxisTitle = xAxisTitle;
    }

    public String getyAxisTitle() {
        return yAxisTitle;
    }

    public void setyAxisTitle(String yAxisTitle) {
        this.yAxisTitle = yAxisTitle;
    }

    public OutputValueType getOutputValueType() {
        return outputValueType;
    }

    public void setOutputValueType(OutputValueType outputValueType) {
        this.outputValueType = outputValueType;
    }

    public DataAggregation getDataAggregation() {
        return dataAggregation;
    }

    public void setDataAggregation(DataAggregation dataAggregation) {
        this.dataAggregation = dataAggregation;
    }

    public List<SourceEpisodeBaseData> getObjectSources() {
        return objectSources;
    }

    public void setObjectSources(List<SourceEpisodeBaseData> objectSources) {
        this.objectSources = objectSources;
    }
}
