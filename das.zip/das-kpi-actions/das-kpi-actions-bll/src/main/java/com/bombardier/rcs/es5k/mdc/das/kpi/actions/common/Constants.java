/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.common;

/**
 * Constants
 *
 * @author Przemyslaw Sikora
 */
public class Constants {

    public static final String KPI_TYPE_NAME = "actions";
    public static final String EPISODE_COLLECTION_NAME = "dasEpisodeConfigurations";

}
