/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display;

import com.bombardier.rcs.es5k.mdc.das.kpi.core.display.MongoDbKpiConfigurationRepository;
import com.bombardier.rcs.es5k.mdc.das.kpi.core.display.SpecificKpiConfigurationConverter;

import javax.inject.Inject;

/**
 * MongoDb Actions Kpi Configuration Repository
 *
 * @author Przemyslaw Sikora
 */
public class MongoDbActionsKpiConfigurationRepository extends MongoDbKpiConfigurationRepository {

    @Inject
    private ActionsKpiConfigurationConverter actionsKpiConfigurationConverter;

    @Override
    protected SpecificKpiConfigurationConverter getSpecificKpiConfigurationConverter() {
        return actionsKpiConfigurationConverter;
    }

}
