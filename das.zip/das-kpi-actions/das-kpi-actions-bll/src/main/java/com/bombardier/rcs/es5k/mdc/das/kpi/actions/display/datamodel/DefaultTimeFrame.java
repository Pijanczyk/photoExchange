/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import java.time.ZonedDateTime;

/**
 * Default Time Frame
 *
 * @author Przemyslaw Sikora
 */
public class DefaultTimeFrame {

    private ZonedDateTime startTime;
    private ZonedDateTime stopTime;
    private Long relativeStartTime;
    private Long relativeStopTime;

    public ZonedDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(ZonedDateTime startTime) {
        this.startTime = startTime;
    }

    public ZonedDateTime getStopTime() {
        return stopTime;
    }

    public void setStopTime(ZonedDateTime stopTime) {
        this.stopTime = stopTime;
    }

    public Long getRelativeStartTime() {
        return relativeStartTime;
    }

    public void setRelativeStartTime(Long relativeStartTime) {
        this.relativeStartTime = relativeStartTime;
    }

    public Long getRelativeStopTime() {
        return relativeStopTime;
    }

    public void setRelativeStopTime(Long relativeStopTime) {
        this.relativeStopTime = relativeStopTime;
    }
}
