/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Value Property
 *
 * @author Przemyslaw Sikora
 */
public enum ValueProperty {

    COUNT("count"), MINIMUM("min"), MAXIMUM("max"), AVERAGE("avg"), RANGE("range");

    private String name;

    ValueProperty(String name) {
        this.name = name;
    }

    @JsonValue
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    public static ValueProperty fromString(String name) {
        for (ValueProperty property : ValueProperty.values()) {
            if (property.name.equals(name)) {
                return property;
            }
        }
        throw new IllegalArgumentException(String.format("Unrecognized value property (%s)", name));
    }

}
