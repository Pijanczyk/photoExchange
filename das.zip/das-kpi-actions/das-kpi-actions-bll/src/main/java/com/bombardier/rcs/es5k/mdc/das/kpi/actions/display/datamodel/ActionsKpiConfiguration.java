/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.common.Constants;
import com.bombardier.rcs.es5k.mdc.das.kpi.core.display.datamodel.SpecificKpiConfiguration;

import java.util.Set;

/**
 * Actions Kpi Configuration
 *
 * @author Przemyslaw Sikora
 */
public class ActionsKpiConfiguration implements SpecificKpiConfiguration {

    private String xAxisTitle;
    private String yAxisTitle;
    private ChartType chartType;
    private Set<String> episodes;
    private Set<String> episodeGroups;
    private Set<String> episodeRatios;
    private Set<String> episodeRatioGroups;
    private OutputValueType outputValueType;
    private AverageMode averageMode;
    private DefaultTimeFrame defaultTimeFrame;
    private DataAggregation dataAggregation;
    private DataLimitation dataLimitation;

    @Override
    public String getKpiType() {
        return Constants.KPI_TYPE_NAME;
    }

    public String getxAxisTitle() {
        return xAxisTitle;
    }

    public void setxAxisTitle(String xAxisTitle) {
        this.xAxisTitle = xAxisTitle;
    }

    public String getyAxisTitle() {
        return yAxisTitle;
    }

    public ChartType getChartType() {
        return chartType;
    }

    public void setChartType(ChartType chartType) {
        this.chartType = chartType;
    }

    public void setyAxisTitle(String yAxisTitle) {
        this.yAxisTitle = yAxisTitle;
    }

    public Set<String> getEpisodes() {
        return episodes;
    }

    public void setEpisodes(Set<String> episodes) {
        this.episodes = episodes;
    }

    public Set<String> getEpisodeGroups() {
        return episodeGroups;
    }

    public void setEpisodeGroups(Set<String> episodeGroups) {
        this.episodeGroups = episodeGroups;
    }

    public Set<String> getEpisodeRatios() {
        return episodeRatios;
    }

    public void setEpisodeRatios(Set<String> episodeRatios) {
        this.episodeRatios = episodeRatios;
    }

    public Set<String> getEpisodeRatioGroups() {
        return episodeRatioGroups;
    }

    public void setEpisodeRatioGroups(Set<String> episodeRatioGroups) {
        this.episodeRatioGroups = episodeRatioGroups;
    }

    public OutputValueType getOutputValueType() {
        return outputValueType;
    }

    public void setOutputValueType(OutputValueType outputValueType) {
        this.outputValueType = outputValueType;
    }

    public AverageMode getAverageMode() {
        return averageMode;
    }

    public void setAverageMode(AverageMode averageMode) {
        this.averageMode = averageMode;
    }

    public DefaultTimeFrame getDefaultTimeFrame() {
        return defaultTimeFrame;
    }

    public void setDefaultTimeFrame(DefaultTimeFrame defaultTimeFrame) {
        this.defaultTimeFrame = defaultTimeFrame;
    }

    public DataAggregation getDataAggregation() {
        return dataAggregation;
    }

    public void setDataAggregation(DataAggregation dataAggregation) {
        this.dataAggregation = dataAggregation;
    }

    public DataLimitation getDataLimitation() {
        return dataLimitation;
    }

    public void setDataLimitation(DataLimitation dataLimitation) {
        this.dataLimitation = dataLimitation;
    }

}
