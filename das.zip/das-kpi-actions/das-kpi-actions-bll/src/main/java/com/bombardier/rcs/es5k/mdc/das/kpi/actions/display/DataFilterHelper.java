/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.SourceAggregationType;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.TimeGranularity;
import com.mongodb.BasicDBObject;
import com.mongodb.client.model.BsonField;
import org.bson.conversions.Bson;

import java.time.DayOfWeek;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.stream.Collectors;

import static com.mongodb.client.model.Filters.*;
import static java.time.temporal.ChronoUnit.MONTHS;
import static java.time.temporal.ChronoUnit.WEEKS;

/**
 * Data Filter Helper
 *
 * @author Przemyslaw Sikora
 */
public class DataFilterHelper {

    private static final int MINIMUM_NUM_GROUPS_PER_TIME_FRAME = 15;
    private static final String TEXT_DATE = "date";
    private static final String TEXT_TIME_PERIOD = "timePeriod";
    private static final String TEXT_SOURCE = "source";
    private static final String TEXT_SOURCE_SYSTEM = "sourceSystem";
    private static final String TEXT_SOURCE_FACILITY = "sourceFacility";
    private static final String TEXT_SOURCE_TYPE = "sourceType";
    private static final String TEXT_EPISODE = "episode";
    private static final String TEXT_EPISODE_GROUP = "episodeGroup";

    private static final String ELEMENT_ID = "_id";
    private static final String ELEMENT_SOURCE = "$source";
    private static final String ELEMENT_SOURCE_SYSTEM = "$sourceSystem";
    private static final String ELEMENT_SOURCE_FACILITY = "$sourceFacility";
    private static final String ELEMENT_SOURCE_TYPE = "$sourceType";
    private static final String ELEMENT_EPISODE = "$episode";
    private static final String ELEMENT_DATE = "$date";

    public Bson getTimeFilter(ZonedDateTime from, ZonedDateTime to) {
        TimeGranularity timeGranularity = getBestTimeGranularity(from, to);
        Date startTimeFrame = Date.from(getFromDate(from, timeGranularity).toInstant());
        Date stopTimeFrame = Date.from(getToDate(to, timeGranularity).toInstant());
        return and(
                gte(TEXT_DATE, startTimeFrame),
                lt(TEXT_DATE, stopTimeFrame),
                eq(TEXT_TIME_PERIOD, timeGranularity.getName()));
    }

    public Bson getFilterForSources(Set<String> facilityReferenceSet, Set<String> systemReferenceSet,
                                    Set<String> deviceReferenceSet) {
        Set<Bson> filter = new HashSet<>();
        if (!facilityReferenceSet.isEmpty()) {
            Set<Bson> facilityFilterSet = facilityReferenceSet.stream().filter(Objects::nonNull)
                    .map(refName -> eq(TEXT_SOURCE_FACILITY, refName)).collect(Collectors.toSet());
            filter.addAll(facilityFilterSet);
        }
        if (!systemReferenceSet.isEmpty()) {
            Set<Bson> systemFilterSet = systemReferenceSet.stream().filter(Objects::nonNull)
                    .map(refName -> eq(TEXT_SOURCE_SYSTEM, refName))
                    .collect(Collectors.toSet());
            filter.addAll(systemFilterSet);
        }
        if (!deviceReferenceSet.isEmpty()) {
            Set<Bson> deviceFilterSet = deviceReferenceSet.stream().filter(Objects::nonNull)
                    .map(refName -> eq(TEXT_SOURCE, refName))
                    .collect(Collectors.toSet());
            filter.addAll(deviceFilterSet);
        }
        return filter.isEmpty() ? null : or(filter);
    }

    public Bson getFilterForDeviceTypes(Set<String> deviceTypeReferenceSet) {
        if (deviceTypeReferenceSet.isEmpty()) {
            return null;
        }
        Set<Bson> filterSet = deviceTypeReferenceSet.stream()
                .map(refName -> eq(TEXT_SOURCE_TYPE, refName))
                .collect(Collectors.toSet());
        return or(filterSet);
    }

    public Bson getFilterForEpisodes(Set<String> episodes, Set<String> episodeGroups) {
        if (isNullOrEmpty(episodes) && isNullOrEmpty(episodeGroups)) {
            return null;
        }
        Set<Bson> episodeFilters = Optional.ofNullable(episodes)
                .orElse(Collections.emptySet()).stream()
                .map(e -> eq(TEXT_EPISODE, e))
                .collect(Collectors.toSet());
        Set<Bson> episodeGroupFilters = Optional.ofNullable(episodeGroups)
                .orElse(Collections.emptySet()).stream()
                .map(e -> eq(TEXT_EPISODE_GROUP, e))
                .collect(Collectors.toSet());

        episodeFilters.addAll(episodeGroupFilters);
        return or(episodeFilters);
    }

    public BsonField getAggregationFilter(
            SourceAggregationType sourceAggregation, Boolean episodeAggregation, Boolean timeAggregation) {
        Set<Bson> filters = new HashSet<>();

        switch (sourceAggregation) {
            case DEVICE:
                filters.add(eq(TEXT_SOURCE, ELEMENT_SOURCE));
                break;

            case SYSTEM:
                filters.add(eq(TEXT_SOURCE, ELEMENT_SOURCE_SYSTEM));
                break;

            case FACILITY:
                filters.add(eq(TEXT_SOURCE, ELEMENT_SOURCE_FACILITY));
                break;

            case DEVICE_TYPE:
                filters.add(eq(TEXT_SOURCE, ELEMENT_SOURCE_TYPE));
                break;

            default:
                break;
        }
        if (!timeAggregation) {
            filters.add(eq(TEXT_DATE, ELEMENT_DATE));
        }
        if (!episodeAggregation) {
            filters.add(eq(TEXT_EPISODE, ELEMENT_EPISODE));
        }

        return new BsonField(ELEMENT_ID, and(filters));
    }

    public TimeGranularity getBestTimeGranularity(ZonedDateTime startTime, ZonedDateTime stopTime) {
        ZonedDateTime from = getFromDateByMonth(startTime, startTime.getZone());
        ZonedDateTime to = getToDateByMonth(stopTime, startTime.getZone());
        if (MONTHS.between(from, to) > MINIMUM_NUM_GROUPS_PER_TIME_FRAME) {
            return TimeGranularity.MONTH;
        }

        from = getFromDateByWeek(startTime, startTime.getZone());
        to = getToDateByWeek(stopTime, startTime.getZone());
        if (WEEKS.between(from, to) > MINIMUM_NUM_GROUPS_PER_TIME_FRAME) {
            return TimeGranularity.WEEK;
        }

        return TimeGranularity.DAY;
    }

    private ZonedDateTime getFromDateByMonth(ZonedDateTime date, ZoneId zone) {
        return date.withZoneSameInstant(zone)
                .withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0).withNano(0);
    }

    private ZonedDateTime getToDateByMonth(ZonedDateTime date, ZoneId zone) {
        ZonedDateTime dateInProperZone = date.withZoneSameInstant(zone);
        ZonedDateTime nextMonth = dateInProperZone.with(TemporalAdjusters.ofDateAdjuster(d -> d.plusMonths(1)));
        return nextMonth.withDayOfMonth(1)
                .withHour(0).withMinute(0).withSecond(0).withNano(0);
    }

    private ZonedDateTime getFromDateByWeek(ZonedDateTime date, ZoneId zone) {
        return date.withZoneSameInstant(zone)
                .with(DayOfWeek.MONDAY).withHour(0).withMinute(0).withSecond(0).withNano(0);
    }

    private ZonedDateTime getToDateByWeek(ZonedDateTime date, ZoneId zone) {
        ZonedDateTime dateInProperZone = date.withZoneSameInstant(zone);
        ZonedDateTime nextWeek = dateInProperZone.with(TemporalAdjusters.ofDateAdjuster(d -> d.plusWeeks(1)));
        return nextWeek.with(DayOfWeek.MONDAY).withHour(0).withMinute(0).withSecond(0).withNano(0);
    }

    private ZonedDateTime getFromDateByDay(ZonedDateTime date, ZoneId zone) {
        return date.withZoneSameInstant(zone)
                .withHour(0).withMinute(0).withSecond(0).withNano(0);
    }

    private ZonedDateTime getToDateByDay(ZonedDateTime date, ZoneId zone) {
        ZonedDateTime dateInProperZone = date.withZoneSameInstant(zone);
        ZonedDateTime nextDay = dateInProperZone.with(TemporalAdjusters.ofDateAdjuster(d -> d.plusDays(1)));
        return nextDay.withHour(0).withMinute(0).withSecond(0).withNano(0);
    }

    private ZonedDateTime getFromDate(ZonedDateTime date, TimeGranularity timeGranularity) {
        if (timeGranularity == TimeGranularity.MONTH) {
            return getFromDateByMonth(date, date.getZone());
        }
        if (timeGranularity == TimeGranularity.WEEK) {
            return getFromDateByWeek(date, date.getZone());
        }
        return getFromDateByDay(date, date.getZone());
    }

    private ZonedDateTime getToDate(ZonedDateTime date, TimeGranularity timeGranularity) {
        if (timeGranularity == TimeGranularity.MONTH) {
            return getToDateByMonth(date, date.getZone());
        }
        if (timeGranularity == TimeGranularity.WEEK) {
            return getToDateByWeek(date, date.getZone());
        }
        return getToDateByDay(date, date.getZone());
    }

    private boolean isNullOrEmpty(Collection collection) {
        return collection == null || collection.isEmpty();
    }

}
