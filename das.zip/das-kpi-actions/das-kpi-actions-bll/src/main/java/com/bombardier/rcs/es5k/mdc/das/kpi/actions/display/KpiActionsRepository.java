/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.KpiActionsDataRequest;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.OlapCellValue;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.SourceAggregationType;
import com.bombardier.rcs.mdc.sdi.model.SDIDevice;
import com.bombardier.rcs.mdc.sdi.model.SDIDeviceType;
import com.bombardier.rcs.mdc.sdi.model.SDIFacility;
import com.bombardier.rcs.mdc.sdi.model.SDISystem;
import com.bombardier.rcs.mdc.sdi.repositories.mongodb.MongoDBClientProviderRepository;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.BsonField;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import javax.inject.Inject;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;

/**
 * Kpi Actions Repository
 *
 * @author Przemyslaw Sikora
 */
public class KpiActionsRepository extends MongoDBClientProviderRepository {

    private static final String COLLECTION_NAME = "dasProcessedData";

    private static final String TEXT_DATE = "date";
    private static final String TEXT_COUNT = "count";
    private static final String TEXT_MIN_DURATION = "minDuration";
    private static final String TEXT_MAX_DURATION = "maxDuration";
    private static final String TEXT_AVG_DURATION = "avgDuration";
    private static final String TEXT_SUM_DURATION = "sumDuration";
    private static final String TEXT_RATIO = "ratio";
    private static final String TEXT_ANTECEDENT = "antecedent";
    private static final String TEXT_CONSEQUENT = "consequent";
    private static final String TEXT_SOURCE = "source";

    private static final String OPERATOR_SUM = "$sum";
    private static final String OPERATOR_MIN = "$min";
    private static final String OPERATOR_MAX = "$max";
    private static final String OPERATOR_AVG = "$avg";

    private static final String ELEMENT_COUNT = "$count";
    private static final String ELEMENT_MIN_DURATION = "$minDuration";
    private static final String ELEMENT_MAX_DURATION = "$maxDuration";
    private static final String ELEMENT_AVG_DURATION = "$avgDuration";
    private static final String ELEMENT_SUM_DURATION = "$sumDuration";
    private static final String ELEMENT_RATIO = "$ratio";
    private static final String ELEMENT_ANTECEDENT = "$antecedent";
    private static final String ELEMENT_CONSEQUENT = "$consequent";
    private static final String ELEMENT_ID_DATE = "_id.date";

    @Inject
    private DataFilterHelper dataFilterHelper;

    public Map<String, Map<String, List<OlapCellValue>>> getData(KpiActionsDataRequest request) {
        Bson matchOperation = createMatchOperation(request);
        Bson groupOperation = createGroupOperation(request);
        Bson sortOperation = createSortOperation(groupOperation);

        List<Bson> operations = new ArrayList<>();
        Optional.ofNullable(matchOperation).ifPresent(operations::add);
        Optional.ofNullable(groupOperation).ifPresent(operations::add);
        Optional.ofNullable(sortOperation).ifPresent(operations::add);

        List<Document> documents = loadDocuments(operations);

        Map<String, Map<String, List<OlapCellValue>>> result = new HashMap<>();

        Map<String, List<Document>> data = splitBySources(request.getSourceAggregation(), documents);
        for (Map.Entry<String, List<Document>> entry : data.entrySet()) {
            result.put(entry.getKey(), splitByEpisodes(request.getEpisodeAggregation(), entry.getValue()));
        }
        return result;
    }

    private Map<String, List<Document>> splitBySources(SourceAggregationType sourceAggregationType, List<Document> documents) {
        Map<String, List<Document>> sourceData = new HashMap<>();
        if (sourceAggregationType == SourceAggregationType.FULL) {
            sourceData.put(TEXT_SOURCE, documents);
            return sourceData;
        }
        for (int i = 0; i < documents.size(); i++) {
            String sourceReference = documents.get(i).get("_id", Document.class).getString(TEXT_SOURCE);
            if (!sourceData.containsKey(sourceReference)) {
                sourceData.put(sourceReference, new ArrayList<>());
            }
            sourceData.get(sourceReference).add(documents.get(i));
        }
        return sourceData;
    }

    private Map<String, List<OlapCellValue>> splitByEpisodes(Boolean episodeAggregation, List<Document> documents) {
        List<OlapCellValue> olapCellValues = documents.stream().map(
                this::convertToOlapCellValue).collect(Collectors.toList());
        Map<String, List<OlapCellValue>> episodeData = new HashMap<>();
        if (episodeAggregation) {
            episodeData.put("episode", olapCellValues);
            return episodeData;
        }
        for (int i = 0; i < documents.size(); i++) {
            String episodeReference = documents.get(i).get("_id", Document.class).getString("episode");
            if (!episodeData.containsKey(episodeReference)) {
                episodeData.put(episodeReference, new ArrayList<>());
            }
            episodeData.get(episodeReference).add(olapCellValues.get(i));
        }
        return episodeData;
    }

    private OlapCellValue convertToOlapCellValue(Document document) {
        OlapCellValue olapCellValue = new OlapCellValue();

        if(document.get("_id") instanceof Boolean) {
            olapCellValue.setSourceReference(TEXT_SOURCE);
            olapCellValue.setEpisodeReference("episode");
            olapCellValue.setTime(null);
        } else if (!(document.get("_id") instanceof ObjectId)) {
            Document idDocument = document.get("_id", Document.class);
            olapCellValue.setSourceReference(idDocument.getString(TEXT_SOURCE));
            olapCellValue.setEpisodeReference(idDocument.getString("episode"));
            if (idDocument.getDate("date") != null) {
                olapCellValue.setTime(idDocument.getDate("date").toInstant().atZone(ZoneId.of("UTC")));
            }
        }

        olapCellValue.setCount(getNumericValue(document, TEXT_COUNT).longValue());
        olapCellValue.setMinDuration(getNumericValue(document, TEXT_MIN_DURATION));
        olapCellValue.setMaxDuration(getNumericValue(document, TEXT_MAX_DURATION));
        olapCellValue.setAvgDuration(getNumericValue(document, TEXT_AVG_DURATION));
        olapCellValue.setSumDuration(getNumericValue(document, TEXT_SUM_DURATION));
        olapCellValue.setRatio(getNumericValue(document, TEXT_RATIO));
        olapCellValue.setAntecedent(getNumericValue(document, TEXT_ANTECEDENT).longValue());
        olapCellValue.setConsequent(getNumericValue(document, TEXT_CONSEQUENT).longValue());
        return olapCellValue;
    }

    private Bson createMatchOperation(KpiActionsDataRequest request) {
        Bson timeFilter = dataFilterHelper.getTimeFilter(request.getTimeFrom(), request.getTimeTo());

        Set<String> facilityReferenceSet = Optional.ofNullable(request.getFacilities()).orElse(Collections.emptySet())
                .stream().filter(Objects::nonNull).map(SDIFacility::getReference).collect(Collectors.toSet());
        Set<String> systemReferenceSet = Optional.ofNullable(request.getSystems()).orElse(Collections.emptySet())
                .stream().filter(Objects::nonNull).map(SDISystem::getReference).collect(Collectors.toSet());
        Set<String> deviceReferenceSet = Optional.ofNullable(request.getDevices()).orElse(Collections.emptySet())
                .stream().filter(Objects::nonNull).map(SDIDevice::getReference).collect(Collectors.toSet());
        Set<String> deviceTypeReferenceSet = Optional.ofNullable(request.getDeviceTypes())
                .orElse(Collections.emptySet()).stream().filter(Objects::nonNull).map(SDIDeviceType::getReference)
                .collect(Collectors.toSet());
        Bson sourceFilter = dataFilterHelper.getFilterForSources(
                facilityReferenceSet, systemReferenceSet, deviceReferenceSet);
        Bson sourceTypeFilter = dataFilterHelper.getFilterForDeviceTypes(deviceTypeReferenceSet);

        Bson episodeFilter = dataFilterHelper.getFilterForEpisodes(request.getEpisodes(), request.getEpisodeGroups());

        Set<Bson> filters = new HashSet<>();
        Optional.ofNullable(timeFilter).ifPresent(filters::add);
        Optional.ofNullable(sourceFilter).ifPresent(filters::add);
        Optional.ofNullable(sourceTypeFilter).ifPresent(filters::add);
        Optional.ofNullable(episodeFilter).ifPresent(filters::add);

        if (filters.isEmpty()) {
            return null;
        }
        return Aggregates.match(and(filters));
    }

    private Bson createGroupOperation(KpiActionsDataRequest request) {
        BsonField aggregationFilter = dataFilterHelper.getAggregationFilter(
                request.getSourceAggregation(), request.getEpisodeAggregation(), request.getTimeAggregation());
        if (aggregationFilter == null) {
            return null;
        }
        return Aggregates.group("group", aggregationFilter,
                new BsonField(TEXT_COUNT, eq(OPERATOR_SUM, ELEMENT_COUNT)),
                new BsonField(TEXT_MIN_DURATION, eq(OPERATOR_MIN, ELEMENT_MIN_DURATION)),
                new BsonField(TEXT_MAX_DURATION, eq(OPERATOR_MAX, ELEMENT_MAX_DURATION)),
                new BsonField(TEXT_AVG_DURATION, eq(OPERATOR_AVG, ELEMENT_AVG_DURATION)),
                new BsonField(TEXT_SUM_DURATION, eq(OPERATOR_SUM, ELEMENT_SUM_DURATION)),
                new BsonField(TEXT_RATIO, eq(OPERATOR_AVG, ELEMENT_RATIO)),
                new BsonField(TEXT_ANTECEDENT, eq(OPERATOR_SUM, ELEMENT_ANTECEDENT)),
                new BsonField(TEXT_CONSEQUENT, eq(OPERATOR_SUM, ELEMENT_CONSEQUENT))
        );
    }

    private Bson createSortOperation(Bson groupOperation) {
        if (groupOperation != null) {
            return Aggregates.sort(eq(ELEMENT_ID_DATE, 1));
        } else {
            return Aggregates.sort(eq(TEXT_DATE, 1));
        }
    }

    private List<Document> loadDocuments(List<Bson> operations) {
        List<Document> documents = new ArrayList<>();
        getManagedCollection().aggregate(operations).iterator().forEachRemaining(documents::add);
        return documents;
    }

    private Double getNumericValue(Document document, String keyName) {
        Object value = Optional.ofNullable(document.getOrDefault(keyName, 0.0)).orElse(0.0);
        if (value instanceof Double)
            return (Double)value;
        if (value instanceof Integer)
            return ((Integer) value).doubleValue();
        return ((Long) value).doubleValue();
    }

    @Override
    protected String getCollectionName() {
        return COLLECTION_NAME;
    }

}
