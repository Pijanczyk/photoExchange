/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.ejb.Remote;
import javax.ejb.Stateless;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel.ActionsKpiConfiguration;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.KpiConfigurationToRObjectConverter;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel.RList;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel.RObject;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel.RString;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel.SpecificKpiConfiguration;

/**
 * Default KpiConfiguration To RObject Converter
 *
 * @author Przemyslaw Sikora
 */
@Stateless
@Remote(KpiConfigurationToRObjectConverter.class)
public class DefaultKpiConfigurationToRObjectConverter implements KpiConfigurationToRObjectConverter {

	@Override
    public RObject convertToRObject(SpecificKpiConfiguration configuration) {
        if (!(configuration instanceof ActionsKpiConfiguration)) {
            throw new IllegalArgumentException(
                    "Actions DefaultKpiConfigurationToRObjectConverter requires ActionsKpiConfiguration as an input configuration");
        }
        
        ActionsKpiConfiguration kpiConfiguration = (ActionsKpiConfiguration) configuration;
        
        
        return null;
    }
	
	@SuppressWarnings("unchecked")
	private List<RObject> convertDataFilters(ActionsKpiConfiguration configuration) {
		
		RList deviceTypes = null;
		RList facilities = null;
		RList systems = null;
		RList devices = null;
		Map<String, RObject> value = new HashMap<>();
		value.put("deviceTypes", deviceTypes);
		value.put("facilities", facilities);
		value.put("systems", systems);
		value.put("devices", devices);
		
		RList dataFilters = new RList();
		dataFilters.setValue(value);
		configuration.getDataFilters().stream().map();
		/*listData.addAll(new ArrayList(configuration.getDataFilters()));
		return listData;*/
	}
	
    
	@SuppressWarnings("unchecked")
	private Map<String, List<RObject>> convertAllEpisodes(ActionsKpiConfiguration configuration) {

		
		Map<String, RObject> mapEpisode = new HashMap<>();
		
		List<RObject> one = new ArrayList<>();
		one.add(new RString("reference"));
		one.add(new RString("groupReference"));
		one.add(new RString("name"));
		one.add(new RString("eventTypes"));
		one.add(new RString("filter"));
		one.add(new RString("episodes"));
		mapEpisode.put("AllEpisodes", one);
		mapEpisode.put("dataFilters", new ArrayList(configuration.getDataFilters()));
		
		return mapEpisode;
	}
}


/*

 * Copyright (C) 2017 Bombardier Transportation
 

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.ejb.Remote;
import javax.ejb.Stateless;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.dt.datamodel.ActionsKpiConfiguration;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.KpiConfigurationToRObjectConverter;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel.RList;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel.RObject;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel.RString;
import com.bombardier.rcs.es5k.mdc.das.shared.kpi.dt.datamodel.SpecificKpiConfiguration;

*//**
 * Default KpiConfiguration To RObject Converter
 *
 * @author Przemyslaw Sikora
 *//*
@Stateless
@Remote(KpiConfigurationToRObjectConverter.class)
public class DefaultKpiConfigurationToRObjectConverter implements KpiConfigurationToRObjectConverter {

	@Override
    public RObject convertToRObject(SpecificKpiConfiguration configuration) {
        if (!(configuration instanceof ActionsKpiConfiguration)) {
            throw new IllegalArgumentException(
                    "Actions DefaultKpiConfigurationToRObjectConverter requires ActionsKpiConfiguration as an input configuration");
        }
        
        ActionsKpiConfiguration kpiConfiguration = (ActionsKpiConfiguration) configuration;
        
        Rlist rList = new RList();
        
        
        return rList;
    }
	
	@SuppressWarnings("unchecked")
	private List<RString> convertDataFilters(ActionsKpiConfiguration configuration) {
		List<RString> listData = new ArrayList<>();
		listData.add(new RString("facilities"));
		listData.add(new RString("systems"));
		listData.add(new RString("devices"));
		listData.add(new RString("deviceTypes"));
		listData.addAll(new ArrayList(configuration.getDataFilters()));
		return listData;
	}
    
	@SuppressWarnings("unchecked")
	private Map<String, List<RObject>> convertAllEpisodes(ActionsKpiConfiguration configuration) {
		
		Map<String, List<RObject>> mapEpisode = new HashMap<>();
		mapEpisode.put("reference", Arrays.asList(new RString("reference")));
		mapEpisode.put("groupReference", Arrays.asList(new RString("groupReference")));
		mapEpisode.put("name", Arrays.asList(new RString("name")));
		mapEpisode.put("eventTypes", Arrays.asList(new RString("evetnTypes")));
		mapEpisode.put("filter", Arrays.asList(new RString("filter")));
		mapEpisode.put("episodes", new ArrayList(configuration.getEpisodes()));
		
		List<List<RObject>> result = mapEpisode.values().stream()
				.collect(Collectors.toList());
		result.get(List<RObject>)
		
		return mapEpisode;
	}
	
	
    @SuppressWarnings("unchecked")
	private Map<String, List<RObject>> convertEpisodeRatio(ActionsKpiConfiguration configuration) {

		Map<String, List<RObject>> mapEpisodeRatio = new HashMap<>();
		mapEpisodeRatio.put("reference", Arrays.asList(new RString("reference")));
		mapEpisodeRatio.put("name", Arrays.asList(new RString("name")));
		mapEpisodeRatio.put("antecedent", Arrays.asList(new RString("antecedent")));
		mapEpisodeRatio.put("consequent", Arrays.asList(new RString("consequent")));
		mapEpisodeRatio.put("episodeRatios", new ArrayList(configuration.getEpisodeRatios()));
		return mapEpisodeRatio;
	}

	private Map<String, List<RObject>> convertMeasurementCondition(SpecificKpiConfiguration configuration) {

		Map<String, List<RObject>> mapMeasurement = new HashMap<>();
		mapMeasurement.put("actionMoment", Arrays.asList(new RString("actionMoment")));
		mapMeasurement.put("baseSourceReference", Arrays.asList(new RString("baseSourceReference")));
		mapMeasurement.put("targetSourceReference", Arrays.asList(new RString("targetSourceReference")));
		mapMeasurement.put("sourceMappingFunction", Arrays.asList(new RString("sourceMappingFunction")));
		mapMeasurement.put("attribute", Arrays.asList(new RString("attribute")));
		mapMeasurement.put("operator", Arrays.asList(new RString("operator")));
		mapMeasurement.put("value", Arrays.asList(new RString("value")));
		return mapMeasurement;
	}
    
    private Map<String, List<RObject>> convertEpisodeFilter(SpecificKpiConfiguration configuration) {
    	
    	Map<String, List<RObject>> mapEpisodeFilter = new HashMap<>();
    	mapEpisodeFilter.put("minimumDuration", Arrays.asList(new RString("minimumDuration")));
    	mapEpisodeFilter.put("maximumDuration", Arrays.asList(new RString("maximumDuration")));
    	mapEpisodeFilter.put("measurementConditions", Arrays.asList(new RString("measurementConditions")));
    	return mapEpisodeFilter;
    }
    
    private Map<String, List<RObject>> convertEventType(SpecificKpiConfiguration configuration) {
    	
    	Map<String, List<RObject>> mapEventType = new HashMap<>();
    	mapEventType.put("name", Arrays.asList(new RString("name")));
    	mapEventType.put("patterns", Arrays.asList(new RString("patterns")));
    	return mapEventType;
    }
    
    private Map<String, List<RObject>> convertObjectFilter(SpecificKpiConfiguration configuration) {
    	
    	Map<String, List<RObject>> mapObjectFilter = new HashMap<>();
    	mapObjectFilter.put("references", Arrays.asList(new RString("references")));
    	mapObjectFilter.put("patterns", Arrays.asList(new RString("patterns")));
    	return mapObjectFilter;
    }
    
    private Map<String, List<RObject>> convertSdiEventTypePattern(SpecificKpiConfiguration configuration) {
    	
    	Map<String, List<RObject>> mapSdi = new HashMap<>();
    	mapSdi.put("reference", Arrays.asList(new RString("reference")));
    	mapSdi.put("severities", Arrays.asList(new RString("severities")));
    	mapSdi.put("states", Arrays.asList(new RString("states")));
    	return mapSdi;
    }
}
*/
