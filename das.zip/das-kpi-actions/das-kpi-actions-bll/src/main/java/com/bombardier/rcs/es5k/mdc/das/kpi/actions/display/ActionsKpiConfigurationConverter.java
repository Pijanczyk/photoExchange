/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.display;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.common.Constants;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.datamodel.*;
import com.bombardier.rcs.es5k.mdc.das.kpi.core.display.SpecificKpiConfigurationConverter;
import com.bombardier.rcs.es5k.mdc.das.kpi.core.display.datamodel.SpecificKpiConfiguration;
import org.bson.Document;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.List;

/**
 * Actions Kpi Configuration Converter
 *
 * @author Przemyslaw Sikora
 */
public class ActionsKpiConfigurationConverter extends SpecificKpiConfigurationConverter {

    private static final String TEXT_X_AXIS_TITLE = "xAxisTitle";
    private static final String TEXT_Y_AXIS_TITLE = "yAxisTitle";
    private static final String TEXT_CHART_TYPE = "chartType";
    private static final String TEXT_EPISODES = "episodes";
    private static final String TEXT_EPISODE_GROUPS = "episodeGroups";
    private static final String TEXT_EPISODE_RATIOS = "episodeRatios";
    private static final String TEXT_EPISODE_RATIO_GROUPS = "episodeRatioGroups";
    private static final String TEXT_OUTPUT_VALUE_TYPE = "outputValueType";
    private static final String TEXT_AVERAGE_MODE = "averageMode";
    private static final String TEXT_DEFAULT_TIME_FRAME = "defaultTimeFrame";
    private static final String TEXT_START_TIME = "startTime";
    private static final String TEXT_STOP_TIME = "stopTime";
    private static final String TEXT_RELATIVE_START_TIME = "relativeStartTime";
    private static final String TEXT_RELATIVE_STOP_TIME = "relativeStopTime";
    private static final String TEXT_DATA_AGGREGATION = "dataAggregation";
    private static final String TEXT_SOURCE = "source";
    private static final String TEXT_EPISODE = "episode";
    private static final String TEXT_TIME = "time";
    private static final String TEXT_DATA_LIMITATION = "dataLimitation";
    private static final String TEXT_SOURCES_MAX = "sourcesMax";
    private static final String TEXT_EPISODES_MAX = "episodesMax";
    private static final String TEXT_DATA_PRIORITY = "dataPriority";
    private static final String TEXT_VALUE_PROPERTY = "valueProperty";
    private static final String TEXT_ACCUMULATOR = "accumulator";
    private static final String TEXT_TARGET_PROPERTY = "targetProperty";

    public ActionsKpiConfigurationConverter() {
        super(Constants.KPI_TYPE_NAME);
    }

    @Override
    public Document convertToDocument(SpecificKpiConfiguration configuration) {
        if (!(configuration instanceof ActionsKpiConfiguration)) {
            throw new IllegalArgumentException(
                    "ActionsKpiConfigurationConverter requires ActionsKpiConfiguration as an input configuration");
        }
        ActionsKpiConfiguration config = (ActionsKpiConfiguration) configuration;
        Document document = getBaseDocument();
        document.append(TEXT_X_AXIS_TITLE, config.getxAxisTitle());
        document.append(TEXT_Y_AXIS_TITLE, config.getyAxisTitle());
        document.append(TEXT_CHART_TYPE, config.getChartType().getName());
        document.append(TEXT_EPISODES, config.getEpisodes());
        document.append(TEXT_EPISODE_GROUPS, config.getEpisodeGroups());
        document.append(TEXT_EPISODE_RATIOS, config.getEpisodeRatios());
        document.append(TEXT_EPISODE_RATIO_GROUPS, config.getEpisodeRatioGroups());
        document.append(TEXT_OUTPUT_VALUE_TYPE, config.getOutputValueType().getName());
        document.append(TEXT_AVERAGE_MODE, config.getAverageMode().getName());
        document.append(TEXT_DEFAULT_TIME_FRAME, convertToDefaultTimeFrameDocument(config.getDefaultTimeFrame()));
        document.append(TEXT_DATA_AGGREGATION, convertToDataAggregationDocument(config.getDataAggregation()));
        document.append(TEXT_DATA_LIMITATION, convertToDataLimitationDocument(config.getDataLimitation()));
        return document;
    }

    @SuppressWarnings("unchecked")
    @Override
    public SpecificKpiConfiguration convertToObject(Document document) {
        ActionsKpiConfiguration configuration = new ActionsKpiConfiguration();
        configuration.setxAxisTitle(document.getString(TEXT_X_AXIS_TITLE));
        configuration.setyAxisTitle(document.getString(TEXT_Y_AXIS_TITLE));
        configuration.setChartType(ChartType.fromString(document.getString(TEXT_CHART_TYPE)));
        List<String> episodeDocs = document.get(TEXT_EPISODES, List.class);
        if (episodeDocs != null) {
            configuration.setEpisodes(new HashSet<>(episodeDocs));
        }
        List<String> episodeGroupDocs = document.get(TEXT_EPISODE_GROUPS, List.class);
        if (episodeGroupDocs != null) {
            configuration.setEpisodeGroups(new HashSet<>(episodeGroupDocs));
        }
        List<String> episodeRatioDocs = document.get(TEXT_EPISODE_RATIOS, List.class);
        if (episodeRatioDocs != null) {
            configuration.setEpisodeRatios(new HashSet<>(episodeRatioDocs));
        }
        List<String> episodeRatioGroupDocs = document.get(TEXT_EPISODE_RATIO_GROUPS, List.class);
        if (episodeRatioGroupDocs != null) {
            configuration.setEpisodeRatioGroups(new HashSet<>(episodeRatioGroupDocs));
        }
        configuration.setOutputValueType(OutputValueType.fromString(document.getString(TEXT_OUTPUT_VALUE_TYPE)));
        configuration.setAverageMode(AverageMode.fromString(document.getString(TEXT_AVERAGE_MODE)));
        configuration.setDefaultTimeFrame(convertToDefaultTimeFrame(
                document.get(TEXT_DEFAULT_TIME_FRAME, Document.class)));
        configuration.setDataAggregation(convertToDataAggregation(
                document.get(TEXT_DATA_AGGREGATION, Document.class)));
        configuration.setDataLimitation(convertToDataLimitation(
                document.get(TEXT_DATA_LIMITATION, Document.class)));
        return configuration;
    }

    private Document convertToDefaultTimeFrameDocument(DefaultTimeFrame defaultTimeFrame) {
        Document document = new Document();
        document.append(TEXT_START_TIME, defaultTimeFrame.getStartTime());
        document.append(TEXT_STOP_TIME, defaultTimeFrame.getStopTime());
        document.append(TEXT_RELATIVE_START_TIME, defaultTimeFrame.getRelativeStartTime());
        document.append(TEXT_RELATIVE_STOP_TIME, defaultTimeFrame.getRelativeStopTime());
        return document;
    }

    private DefaultTimeFrame convertToDefaultTimeFrame(Document document) {
        DefaultTimeFrame defaultTimeFrame = new DefaultTimeFrame();
        defaultTimeFrame.setStartTime(ZonedDateTime.ofInstant(
                document.getDate(TEXT_START_TIME).toInstant(), ZoneId.of("UTC")));
        defaultTimeFrame.setStopTime(ZonedDateTime.ofInstant(
                document.getDate(TEXT_STOP_TIME).toInstant(), ZoneId.of("UTC")));
        defaultTimeFrame.setRelativeStartTime(document.getLong(TEXT_RELATIVE_START_TIME));
        defaultTimeFrame.setRelativeStopTime(document.getLong(TEXT_RELATIVE_STOP_TIME));
        return defaultTimeFrame;
    }

    private Document convertToDataAggregationDocument(DataAggregation dataAggregation) {
        Document document = new Document();
        document.append(TEXT_SOURCE, dataAggregation.getSource().getName());
        document.append(TEXT_EPISODE, dataAggregation.getEpisode());
        document.append(TEXT_TIME, dataAggregation.getTime());
        return document;
    }

    private DataAggregation convertToDataAggregation(Document document) {
        DataAggregation dataAggregation = new DataAggregation();
        dataAggregation.setSource(SourceAggregationType.fromString(document.getString(TEXT_SOURCE)));
        dataAggregation.setEpisode(document.getBoolean(TEXT_EPISODE));
        dataAggregation.setTime(document.getBoolean(TEXT_TIME));
        return dataAggregation;
    }

    private Document convertToDataLimitationDocument(DataLimitation dataLimitation) {
        Document document = new Document();
        document.append(TEXT_SOURCES_MAX, dataLimitation.getSourcesMax());
        document.append(TEXT_EPISODES_MAX, dataLimitation.getEpisodesMax());
        document.append(TEXT_DATA_PRIORITY, dataLimitation.getDataPriority().getName());
        document.append(TEXT_VALUE_PROPERTY, dataLimitation.getValueProperty().getName());
        document.append(TEXT_ACCUMULATOR, dataLimitation.getAccumulator().getName());
        document.append(TEXT_TARGET_PROPERTY, dataLimitation.getTargetProperty().getName());
        return document;
    }

    private DataLimitation convertToDataLimitation(Document document) {
        DataLimitation dataLimitation = new DataLimitation();
        dataLimitation.setSourcesMax(document.getInteger(TEXT_SOURCES_MAX));
        dataLimitation.setEpisodesMax(document.getInteger(TEXT_EPISODES_MAX));
        dataLimitation.setDataPriority(DataPriority.fromString(document.getString(TEXT_DATA_PRIORITY)));
        dataLimitation.setValueProperty(ValueProperty.fromString(document.getString(TEXT_VALUE_PROPERTY)));
        dataLimitation.setAccumulator(Accumulator.fromString(document.getString(TEXT_ACCUMULATOR)));
        dataLimitation.setTargetProperty(TargetProperty.fromString(document.getString(TEXT_TARGET_PROPERTY)));
        return dataLimitation;
    }

}
