/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.common;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.common.datamodel.Episode;

/**
 * Episode Repository
 *
 * @author Przemyslaw Sikora
 */
public class EpisodeRepository extends AbstractEpisodeRepository<String, Episode> {

    protected static final String TEXT_EPISODE = "episode";

    @Override
    protected String getObjectType() {
        return TEXT_EPISODE;
    }

    @Override
    protected Episode createNewObject() {
        return new Episode();
    }

}
