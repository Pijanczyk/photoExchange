setwd("C:/Users/zwseda/Documents/r-scripts/other/EventProcessor")
#################------------EVENT PROCESSOR------------#######################
### Script analyzes event combinations patterns configured by users (episodes).
### Single specific occurence of episode is called an action.
### User has to specificate event and state A (which is starting point of an action),
### and can also specificate event and state B (stopping point of and action).
### In addition there is filtering section to specify constraints.
### Main functionalities are aggregation of dt by time, device and action,
### setting constraints for max and min duration time
### and filtering by desired value of another or the same device measurements
### at the time of analyzed event

### DATA TO OVERWRITE
source("Example_config.R")
source("general_settings_new.R")
###

library(data.table)
library(plyr)
library(dplyr)
library(lubridate)
library(magrittr)
library(sqldf)
library(mongolite)
library(compiler)

##################----------CONNECTING TO DB----------##########################
connect_to_db <- function(collection_name,db_name,db_url) {
  connection <- mongo(
    collection = collection_name,
    db = db_name,
    url = db_url,
    verbose = TRUE
  )
  return(connection)
}

accessing_data_from_db <- function(db_connection, query, sort = '{"timestamp" : 1}') {
   data_table <- db_connection$find(
    query = query, sort = sort
  )
  return(data_table)
}

# in output collection: result are inserted, documents older than specified time
# are removed, in agent collection: time of last scipt launch is added to
# corresponding agent
output_into_database <- function(output_tables, ratio_tables, agent_collection, output_collection,
                                 agent_id, current_time, threshold_of_removal) {
  if(exists("output_tables")){
    lapply(output_tables, function(output_table)
      if(!empty(output_table)) output_collection$insert(output_table))}
  
  if(exists("ratio_tables")){
    lapply(ratio_tables, function(ratio_table)
      if(!empty(ratio_table)) output_collection$insert(ratio_table))}
  
  agent_collection$update(
    query = sprintf('{"_id":{"$oid":"%s"}}', agent_id),
    update = sprintf(
      '{"$set":{"lastUpdate": {"$date": {"$numberLong":"%s"}}}}',
      as.character(floor(as.numeric(current_time) * 1000))
    )
  )
  
  
  threshold_timestamp <- as.character(as.integer(current_time - threshold_of_removal) * 1000)
  
  output_collection$remove(
    query = sprintf(
      '{"jobId": "%s", "timestamp": {"$lt": {"$date": {"$numberLong":"%s"}}}}',
      agent_id,
      threshold_timestamp
    ),
    just_one = FALSE
  )
}

#####################------------LOGIC------------#############################

ignore_state_cases <- function(all_episodes) {
  return(lapply(all_episodes, function(episode) {
    if(!is.null(episode$event_state_A)) {episode$event_state_A <- tolower(episode$event_state_A)}
    if(!is.null(episode$event_state_B)) {episode$event_state_B <- tolower(episode$event_state_B)}
    return(episode)
  }))
}

# support list of filtering constraints demarked from episode configurations
group_all_filtering_constraints <- function(all_episodes) {
  
  all_filtering_constraints <- list()
  all_filtering_constraints <- sapply(all_episodes, function(x) {
    dataset = list()
    dataset[[as.character(x$episode_name[1])]] <-
      x[grepl("filters(.+?)", names(x))]
    dataset <- lapply(dataset, unique)
    return(dataset)
  })
  
  return(all_filtering_constraints[sapply(all_filtering_constraints, function(x)
    ncol(x) > 0)])
}

# conversion of input dt to flat dt table
# adding artificial event 'timeNow' to list of existing events types accessed from database
# 'timeNow'serves only as marker of current script launch time and supports counting 
# events that started and not finished before current script launch time
# 'timeNow' is created for each device
process_event_data_input <- function(in_input) {
  event_data <- in_input %$% data.table(
    event = sdi_object$event,
    eventType = sdi_object$eventType,
    source = sdi_object$object,
    state = tolower(sdi_object$state),
    time = as.numeric(sdi_object$time),
    sourceType = objectType,
    sourceSystem = objectSystem,
    sourceFacility = objectFacility,
    stringsAsFactors = FALSE
  )
  
  temp_table <- data.table()
  temp_table <- ldply(all_episodes, function(episode) {
    if ("timenow" %in% tolower(episode$event_type_B)) {
      device_names <-
        event_data[match(as.character(episode$event_type_A), eventType) , list(source = unique(source)), by = c("sourceType", "sourceSystem", "sourceFacility")]
      for (i in 1:nrow(device_names)) {
        time_now <- device_names %$% data.table(
          event = 'event/x',
          eventType = 'timeNow',
          source = source[i],
          state = "no state",
          time = now,
          sourceType = sourceType[i],
          sourceSystem = sourceSystem[i],
          sourceFacility = sourceFacility[i],
          stringsAsFactors = FALSE
        )
        temp_table <- rbind(temp_table, time_now)
      }
    }
    return(temp_table)
  })
  
  return(rbind(event_data, temp_table))
}


# finding all kind of combination between event A and event B 
# in each configured episode pattern
create_event_combinations_table_element <- function(episode) {
  if (("filters.max_duration" %in% names(episode)) ||
      !is.null(episode$filters.max_duration)) {
    episode$filters.max_duration <- NULL
  }
  if ("filters.min_duration" %in% names(episode) ||
      !is.null(episode$filters.min_duration)) {
    episode$filters.min_duration <- NULL
  }
  
  if ("event_type_B" %in% names(episode)) {
    merged_episode <-
      data.table(event_A =
                   c(rep("nd", nrow(episode))), event_B = c(rep("nd", nrow(episode))))
    
    
    lapply(1:nrow(episode), function(i) {
      set(merged_episode, i, "event_A", value = paste(episode[i, "event_type_A"], episode[i, "event_state_A"], sep = ", "))
      set(merged_episode, i, "event_B", value = paste(episode[i, "event_type_B"], episode[i, "event_state_B"], sep = ", "))
    })
    
    all_combinations <- CJ(c(merged_episode[,1]$event_A),c(merged_episode[,2]$event_B))

    episode_temp <- data.table()
    episode_temp <- ldply(1:nrow(all_combinations), function(i) {
      a <- strsplit(as.character(all_combinations[i, 1]), ", ")[[1]]
      b <- strsplit(as.character(all_combinations[i, 2]), ", ")[[1]]
      episode_temp <- rbind(episode_temp, list(event_type_A = a[1],
                               event_state_A = a[2],
                               event_type_B= b[1],
                               event_state_B = b[2]))
    })
    
    return (cbind(episode_name = rep(episode[1, "episode_name"], nrow(episode_temp)), episode_temp))
  }
  return (cbind(episode_name = rep(episode[1, "episode_name"], nrow(episode)), episode[, -1]))
}

##--creating combinations table for every group and merging into config table --##
create_event_combinations_table <- function(all_episodes) {
  args <- ldply(all_episodes, create_event_combinations_table_element)
  return(as.data.table(plyr::rbind.fill(args)))
}

# filtering events by maximum or minimum desired duration
filter_by_duration_constraints <- function(episodes, all_filtering_constraints) {
  episode_name <- as.character(episodes$episode)
  
  if (!is.na(episodes$maxDuration) && !is.na(episodes$minDuration)) {
    max_duration <- episodes$maxDuration
    min_duration <- episodes$minDuration
    if (exists("filters") && "max_duration" %in% names(filters)) {
      max_duration <- filters$max_duration
    }
    
    if (episode_name %in% names(all_filtering_constraints) &&
        "filters.max_duration" %in% names(all_filtering_constraints[[episode_name]])) {
      max_duration <-
        as.numeric(all_filtering_constraints[[episode_name]][["filters.max_duration"]])
    }
    
    if (exists("filters") && "min_duration" %in% names(filters)) {
      min_duration <- filters$min_duration
    }
    
    if (episode_name %in% names(all_filtering_constraints) &&
        "filters.min_duration" %in% names(all_filtering_constraints[[episode_name]])) {
      min_duration <-
        as.numeric(all_filtering_constraints[[episode_name]][["filters.min_duration"]])
    }
    
    episodes <- episodes[which(max_duration >= episodes$maxDuration &
                               min_duration <= episodes$minDuration),]

  }
  return(episodes)
}

# general info added to finished output
add_additional_info <- function(episodes, source, config) {
  episodes[['source']] <- source$name
  episodes[['sourceType']] <- source$type
  episodes[['sourceSystem']] <- source$system
  episodes[['sourceFacility']] <- source$facility
  episodes[['episode']] <- config$episode_name
  
  return(episodes)
}

# returns boolean,
# checks if given event pair fullfills assumptions about
# particular value of measurement on other or the same device at the time of
# analyzed event

# basic measurement db dt processing
measurement_points <- do.call(rbind, lapply(in_input2$sdi_object$measurementPoints, data.table, stringsAsFactors=FALSE))
measurement_data <- in_input2 %$% data.table(
  sourceType = objectType,
  sourceSystem = objectSystem,
  sourceFacility = objectFacility,
  source = sdi_object$object,
  time = as.numeric(sdi_object$time),
  measurement_key = measurement_points$key,
  measurement_value = measurement_points$value,
  stringsAsFactors = FALSE)

is_dependency_with_measurements <-
  function(config, event_A, event_B) {
    all_conditions_true = TRUE
    if(exists("measurement_data", where = 1) || empty(measurement_data)) return(all_conditions_true)
    
    event_name <- as.character(config$episode_name)
    # do exists filter for specific kind of episode pattern and filter for all episodes?
    specific_constraint <-
      event_name %in% names(all_filtering_constraints) &&
      any(grepl(
        "filters.measurement_condition(.+?)",
        names(all_filtering_constraints[[event_name]])
      )) &&
      all(all_filtering_constraints[[event_name]]$filters.measurement_condition.operator %in% OPERATORS)
    
    general_constraint <- exists("filters") &&
      "measurement_condition" %in% names(filters) &&
      filters$measurement_condition$operator %in% OPERATORS
    
    # set conditions from correct filter
    if (general_constraint && !specific_constraint) {
      measurement_condition <- filters$measurement_condition
    } else if ((!general_constraint &&
                specific_constraint) ||
               (general_constraint && specific_constraint)) {
      measurement_condition <-
        all_filtering_constraints[[event_name]]
      measurement_condition <-
        setNames(measurement_condition, lapply(names(measurement_condition), function(x) {
          name <- strsplit(x, split = "\\.")
          return(name[[1]][length(name[[1]])])
        }))
    } else {
      measurement_condition = NA
    }
    
    # find out if user want to analyze by opening or closing event of episode
    if (all(!is.na(measurement_condition))) {
      if ((measurement_condition$filter_time == "stop" &&
           !missing(event_B))) {
        comparison_point <- event_B
      } else if (measurement_condition$filter_time == "start" &&
                 !missing(event_A)) {
        comparison_point <- event_A
      }
      
      # find out if there are any measurements that match desired time, and measurement key and value
      # in chosen device for corresponding analyzed device
      if ((exists("comparison_point") &
           !is.null(comparison_point) &
           (nrow(comparison_point) != 0)) &
          all(!is.na(comparison_point))) {
        matching_base_source_condition <-
          grepl(
            pattern = measurement_condition$base_source,
            x = comparison_point$source,
            perl = TRUE
          )
        matching_target_source_condition <-
          grepl(
            pattern = measurement_condition$target_source,
            x = measurement_data$source,
            perl = TRUE
          )
        
        if (matching_base_source_condition &
            any(matching_target_source_condition)) {
          measurement_check <- measurement_data[matching_target_source_condition,]
          
          matching_time_condition <-
            (measurement_check$time <= comparison_point$time)
          measurement_check <-
            measurement_check[matching_time_condition,]
          measurement_check <-
            measurement_check[nrow(measurement_check),]
          
          
          switch(as.character(measurement_condition$operator),
                 equals = {
                   matching_key_value_condition <-
                     measurement_check$measurement_key == as.character(measurement_condition$attribute) &&
                     measurement_check$measurement_value  == measurement_condition$value
                 })
          measurement_check <-
            measurement_check[matching_key_value_condition,]
          all_conditions_true <- nrow(measurement_check) != 0
        } else {
          all_conditions_true = FALSE
        }
        
      } else {
        all_conditions_true = FALSE
      }
      
    }
    
    return(all_conditions_true)
    
  }

#returns combination of specified events that fitting duration constraints
find_episode_pattern <- function(event_data, config) {
  episodes <- data.table()
  event_A_condition <- event_data$eventType == config$event_type_A &
    event_data$state == config$event_state_A
  
  table_A <- event_data[event_A_condition, ]
  
  for (i in 1:nrow(table_A)) {
    event_A <- table_A[i, ]
    event_B_condition <- event_data$eventType == config$event_type_B &
      (event_data$state == config$event_state_B & event_data$time > event_A$time)
    
    if (i < nrow(table_A))
      event_B_condition %<>% `&` (event_data$time < as.numeric(table_A[i + 1, 'time']))
    event_B <- event_data[event_B_condition, ][1, ]
    
    # filtering by dependent measurements
    if (!is_dependency_with_measurements(config, event_A = event_A, event_B = event_B)) next
    
    if (!is.na(event_B$event)) {
      new_episode <- data.table(
        "eventA" = event_A$event,
        "eventTimeA" = event_A$time,
        "eventB" = event_B$event,
        "eventTimeB" = event_B$time,
        stringsAsFactors = FALSE
      )
      if (nrow(episodes) == 0) {
        episodes <- (new_episode)
      } else {
        episodes <- rbind(episodes, new_episode)
      }
      
    }
  }
  
  return(episodes)
}

# main functions, find patterns in input dt, filter them and create initial output
# for episode with only event A and episodes with both events
process_data_for_single_event <- function(event_data, config) {
  episodes <- data.table()
  event_A_condition <-
    (event_data$eventType == config$event_type_A) &
    (event_data$state == config$event_state_A)
  table_A <- (event_data[event_A_condition, ])
  if (nrow(table_A) == 0)
    return(episodes)
  
  table_A %<>% ddply(1, function(event)
    ifelse(is_dependency_with_measurements(config, event_A = event),
           return(event),
           return(data.table()))
  ) %<>% as.data.table()
  
  if (nrow(table_A) == 0)
    return(episodes)
  
  table_A[['date']] <- as.POSIXct(table_A$time / 1000, origin = "1970-01-01")
  
  episodes <- table_A[,list(count = length(event)), by = date]
  episodes <- episodes[, `:=`(
    avgDuration = NA,
    minDuration = NA,
    maxDuration = NA,
    sumDuration = NA
  )]
  
  return(episodes)
}

process_data <- function(event_data, source, config) {
  
  if (is.null(config$event_type_B) || is.na(config$event_type_B)) {
    episodes <- process_data_for_single_event(event_data, config)
  } else {
    episodes <- find_episode_pattern(event_data,config)
    
    if (nrow(episodes) == 0) return(episodes)
  
    episodes <-
      episodes[, `:=`(
        duration = episodes$eventTimeB - episodes$eventTimeA,
        date = as.POSIXct(episodes$eventTimeB / 1000, origin = "1970-01-01")
      )]
    
    episodes <-
      episodes[, list(
        count = length(duration),
        avgDuration = mean(duration),
        minDuration = min(duration),
        maxDuration = max(duration),
        sumDuration = sum(duration)
      ), by = "date"]
    

  }
  
  
  if (nrow(episodes) == 0) return(episodes)
  
  episodes %<>% add_additional_info(source, config) 
  episodes %<>% filter_by_duration_constraints(all_filtering_constraints)
  
  if (nrow(episodes) == 0) return(episodes)
  
  return(episodes)
}

process_source <- function(event_data, source, output,event_combinations_table) {
  bind_output <- function(event_data, output) {return(rbind(output, event_data))}

  output <- ldply(1:nrow(event_combinations_table), function(i) {
    config <- event_combinations_table[i, ]
    episodes <- as.data.table(process_data(event_data, source, config))
    if (nrow(episodes) > 0) output <- bind_output(episodes, output)
  })
  
  return(as.data.table(output))
}

# main function,
# analyzes dt and finds episode patterns, aggregates them by event and device,
# and then merge into one output_table
produce_basic_output <- function(event_data,event_combinations_table){
  process_source <- cmpfun(process_source)
  process_data <- cmpfun(process_data)

  
  # database empty scheme
  output_table <- data.table(
    date = as.POSIXct(character()),
    count = integer(),
    avgDuration = numeric(),
    minDuration = numeric(),
    maxDuration = numeric(),
    sumDuration = numeric(),
    source = character(),
    sourceType = character(),
    sourceSystem = character(),
    sourceFacility = character(),
    episode = factor())
  
  
  # support table to analyze dt by device
  event_data_list <- split(event_data, event_data$source)
  source <- list(name = "", facility = "", system = "", type = "")
  
  
  output_table <- ldply(names(event_data_list), function(source_name) {
    source$name <- source_name
    source$facility <- event_data_list[[source_name]]$sourceFacility[1]
    source$system <- event_data_list[[source_name]]$sourceSystem[1]
    source$type <- event_data_list[[source_name]]$sourceType[1]
    
    return(process_source(event_data_list[[source_name]], source, output_table,event_combinations_table))
    
  }) 

  return(as.data.table(output_table))
}

# final aggregation for every episode by date constraints to create finished output
aggregate_by_time_range_and_episode <- function(output_table, aggregation_type) {
  #format to ISODate with specific hour set
  properly_date_formatting <-
    function(set_date,set_hour = 0, set_minute = 0, set_second = 0) {
      set_date %<>% as.POSIXct()
      hour(set_date) <- set_hour
      minute(set_date) <- set_minute
      second(set_date) <- set_second
      set_date %<>% format("%Y-%m-%d %H:%M:%S")
      return(set_date)
    }
  
  if (aggregation_type %in% AGGREGATION_TYPES && nrow(output_table) != 0) {
    
    if (aggregation_type == "week") {
      output_table$date %<>%
        ceiling_date(aggregation_type)  %>% - days(6)
    } else {
      output_table$date %<>%
        ceiling_date(aggregation_type)
    }
    
    without_na <- output_table %>% na.omit
    without_na <- without_na[,list(count = sum(count), avgDuration = mean(avgDuration),
                minDuration = min(minDuration), maxDuration = max(maxDuration),
                sumDuration = sum(sumDuration)), by = list(date,
                                                          source,
                                                          sourceType,
                                                          sourceSystem,
                                                          sourceFacility,
                                                          episode)]
      
    with_na <- output_table[which(is.na(minDuration) &
                                    is.na(avgDuration) &
                                    is.na(maxDuration) &
                                    is.na(sumDuration)), ]
    with_na <- with_na[, list(
      count = sum(count),
      avgDuration = mean(avgDuration),
      minDuration = min(minDuration),
      maxDuration = max(maxDuration),
      sumDuration = sum(sumDuration)
    ), by = list(date,
                 source,
                 sourceType,
                 sourceSystem,
                 sourceFacility,
                 episode)]
    
    output_table <- rbind(without_na, with_na)
    
    output_table <- output_table[,`:=`(episodeGroup = "alarms",
                                       type = "episodeBase",
                                       timePeriod = aggregation_type,
                                       jobId = in_agentId,
                                       timestamp = now_for_db)]

    output_table <- output_table[,list(
                      date,
                       timePeriod,
                       source,
                       sourceSystem,
                       sourceFacility,
                       sourceType,
                       episode,
                       episodeGroup,
                       count,
                       minDuration,
                       maxDuration,
                       avgDuration,
                       sumDuration,
                       timestamp,
                       jobId,
                       type)]
    output_table <-  output_table[order(episode)]

    output_table$date %<>% properly_date_formatting()

    return(output_table)
  }
  return(NULL)
}

##-- counting ratios block --##

count_ratios <- function(output_table, ratio_list) {
  if (exists("ratio_list",where = 1) && nrow(output_table) != 0) {

    ratios_counted <- data.table()

    ratios_counted <- ldply(seq_along(ratio_list), function(i){
       numerator <- output_table[output_table$episode %in% as.character(ratio_list[[i]]$episodes_A_names),
                    list(numerator_count = sum(count)),
                    by=c("date","episode","source","timePeriod","sourceSystem",
                                                   "sourceFacility","sourceType")]
       denominator <- output_table[output_table$episode %in% as.character(ratio_list[[i]]$episodes_B_names),
                            list(denominator_count = sum(count)),
                            by=c("date","episode","source","timePeriod","sourceSystem",
                                 "sourceFacility","sourceType")]
       
       joined <- numerator[denominator, on = c("date","episode","source","timePeriod","sourceSystem",
                              "sourceFacility","sourceType")]
       ratio <- joined[,list(ratio = paste0(formatC(100 * numerator_count / denominator_count,format = 'f', digits = 0 ),"%"))]
       
       single_ratio <-
         data.table(
           date = joined$date,
           timePeriod = joined$timePeriod,
           source = joined$source,
           sourceSystem = joined$sourceSystem,
           sourceFacility = joined$sourceFacility,
           sourceType = joined$sourceType,
           episodeRatio = joined$episode,
           episodeRatioGroup = rep("alarms", nrow(joined)),
           ratio = ratio,
           antecedent = joined$numerator_count,
           consequent = joined$denominator_count,
           timestamp = now_for_db,
           jobId = in_agentId,
           type = "episodeRatio"
         )
     
       ratios_counted <- rbind(ratios_counted,single_ratio)
       
       })
    
    # removing corresponding output_table from global environment
    assign(deparse(substitute(output_table)), NULL, pos = 1)
    return(ratios_counted)
  }
  return(NULL)
}
produce_basic_output <- cmpfun(produce_basic_output)
###################----------EXECUTION BLOCK-----------#########################

## database connection
# event_collection <- connect_to_db(EVENT_COLLECTION,DB_NAME,DB_URL)
# measurement_collection <- connect_to_db(MEASUREMENT_COLLECTION,DB_NAME,DB_URL)
# in_input <- accessing_data_from_db(event_collection,EVENT_QUERY)
# in_input2 <- accessing_data_from_db(measurement_collection, MEASUREMENT_QUERY)

## state formatting unification
# workaround for purposes of current config schema, will be change in new schema

## initial dt processing
all_episodes <- ignore_state_cases(all_episodes)
all_filtering_constraints <- group_all_filtering_constraints(all_episodes)
event_data <- process_event_data_input(in_input)
event_combinations_table <- create_event_combinations_table(all_episodes)

# analysis & output creation
output_table <- produce_basic_output(event_data,event_combinations_table)
output_table1 <- aggregate_by_time_range_and_episode(output_table, "day")
output_table2 <- aggregate_by_time_range_and_episode(output_table, "week")
output_table3 <- aggregate_by_time_range_and_episode(output_table, "month")
ratios_table1 <- count_ratios(output_table1, ratio_list)
ratios_table2 <- count_ratios(output_table2, ratio_list)
ratios_table3 <- count_ratios(output_table3, ratio_list)
## sending dt to database
# output_collection <- connect_to_db(OUTPUT_COLLECTION,DB_NAME,DB_URL)
# agent_collection <- connect_to_db(AGENT_COLLECTION,DB_NAME,DB_URL)
# output_into_database(list(output_table1 = output_table1,output_table2 = output_table2,output_table3 = output_table3),
#                      list(ratios_table1 = ratios_table1,ratios_table2 = ratios_table2, ratios_table3 =ratios_table3),
#                      agent_collection, output_collection,
#                      in_agentId, now_for_db, LAST_DATA_LEFT_TIME)
