ratios_for_day <-
  structure(
    list(
      date = c(
        "2017-01-04 00:00:00",
        "2017-01-05 00:00:00",
        "2017-01-06 00:00:00",
        "2017-01-07 00:00:00",
        "2017-07-11 00:00:00",
        "2017-07-11 00:00:00",
        "2017-01-04 00:00:00",
        "2017-01-05 00:00:00",
        "2017-01-07 00:00:00",
        "2017-01-08 00:00:00",
        "2017-07-11 00:00:00",
        "2017-01-04 00:00:00",
        "2017-01-05 00:00:00",
        "2017-07-11 00:00:00",
        "2017-07-11 00:00:00"
      ),
      timePeriod = c(
        "day",
        "day",
        "day",
        "day",
        "day",
        "day",
        "day",
        "day",
        "day",
        "day",
        "day",
        "day",
        "day",
        "day",
        "day"
      ),
      source = c(
        "controllers/switch_1",
        "controllers/switch_2",
        "controllers/switch_2",
        "controllers/switch_1",
        "controllers/switch_1",
        "controllers/switch_2",
        "controllers/train_1",
        "controllers/train_1",
        "controllers/train_1",
        "controllers/train_1",
        "controllers/train_1",
        "controllers/switch_1",
        "controllers/switch_1",
        "controllers/switch_1",
        "controllers/switch_2"
      ),
      sourceSystem = c(
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC"
      ),
      sourceFacility = c(
        "facilities/f1",
        "facilities/f2",
        "facilities/f2",
        "facilities/f1",
        "facilities/f1",
        "facilities/f2",
        "facilities/f1",
        "facilities/f1",
        "facilities/f1",
        "facilities/f1",
        "facilities/f1",
        "facilities/f1",
        "facilities/f1",
        "facilities/f1",
        "facilities/f2"
      ),
      sourceType = c(
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Train",
        "products/ATS/device_types/Train",
        "products/ATS/device_types/Train",
        "products/ATS/device_types/Train",
        "products/ATS/device_types/Train",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch"
      ),
      episodeRatio = structure(
        c(1L, 1L, 1L, 1L, 1L, 1L, 3L, 3L,
          3L, 3L, 3L, 2L, 2L, 2L, 2L),
        .Label = c(
          "pm_switch_normal",
          "pm_switch_reverse",
          "train_comm_lost",
          "global_failure"
        ),
        class = "factor"
      ),
      episodeRatioGroup = c(
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms"
      ),
      ratio.ratio = c(
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%"
      ),
      antecedent = c(1L, 2L, 1L, 2L, 2L, 2L, 1L, 4L, 3L, 1L,
                     4L, 1L, 1L, 2L, 1L),
      consequent = c(1L, 2L, 1L, 2L, 2L, 2L, 1L,
                     4L, 3L, 1L, 4L, 1L, 1L, 2L, 1L),
      timestamp = structure(
        c(
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262
        ),
        tzone = "",
        class = c("POSIXct", "POSIXt")
      ),
      jobId = c(
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d"
      ),
      type = c(
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio"
      )
    ),
    class = "data.frame",
    .Names = c(
      "date",
      "timePeriod",
      "source",
      "sourceSystem",
      "sourceFacility",
      "sourceType",
      "episodeRatio",
      "episodeRatioGroup",
      "ratio.ratio",
      "antecedent",
      "consequent",
      "timestamp",
      "jobId",
      "type"
    ),
    row.names = c(NA, -15L)
  )

ratios_for_week <-
  structure(
    list(
      date = c(
        "2017-01-02 00:00:00",
        "2017-01-02 00:00:00",
        "2017-01-02 00:00:00",
        "2017-01-02 00:00:00",
        "2017-07-10 00:00:00",
        "2017-07-10 00:00:00",
        "2017-07-10 00:00:00",
        "2017-07-10 00:00:00",
        "2017-07-10 00:00:00"
      ),
      timePeriod = c(
        "week",
        "week",
        "week",
        "week",
        "week",
        "week",
        "week",
        "week",
        "week"
      ),
      source = c(
        "controllers/switch_1",
        "controllers/switch_2",
        "controllers/train_1",
        "controllers/switch_1",
        "controllers/switch_1",
        "controllers/switch_2",
        "controllers/train_1",
        "controllers/switch_1",
        "controllers/switch_2"
      ),
      sourceSystem = c(
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC"
      ),
      sourceFacility = c(
        "facilities/f1",
        "facilities/f2",
        "facilities/f1",
        "facilities/f1",
        "facilities/f1",
        "facilities/f2",
        "facilities/f1",
        "facilities/f1",
        "facilities/f2"
      ),
      sourceType = c(
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Train",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Train",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch"
      ),
      episodeRatio = structure(
        c(1L, 1L, 3L, 2L, 1L, 1L, 3L, 2L,
          2L),
        .Label = c(
          "pm_switch_normal",
          "pm_switch_reverse",
          "train_comm_lost",
          "global_failure"
        ),
        class = "factor"
      ),
      episodeRatioGroup = c(
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms"
      ),
      ratio.ratio = c(
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%"
      ),
      antecedent = c(3L, 3L, 9L, 2L,
                     2L, 2L, 4L, 2L, 1L),
      consequent = c(3L, 3L, 9L, 2L, 2L, 2L, 4L,
                     2L, 1L),
      timestamp = structure(
        c(
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262
        ),
        tzone = "",
        class = c("POSIXct", "POSIXt")
      ),
      jobId = c(
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d"
      ),
      type = c(
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio"
      )
    ),
    class = "data.frame",
    row.names = c(NA, -9L),
    .Names = c(
      "date",
      "timePeriod",
      "source",
      "sourceSystem",
      "sourceFacility",
      "sourceType",
      "episodeRatio",
      "episodeRatioGroup",
      "ratio.ratio",
      "antecedent",
      "consequent",
      "timestamp",
      "jobId",
      "type"
    )
  )


ratios_for_month <-
  structure(
    list(
      date = c(
        "2017-02-01 00:00:00",
        "2017-02-01 00:00:00",
        "2017-02-01 00:00:00",
        "2017-02-01 00:00:00",
        "2017-08-01 00:00:00",
        "2017-08-01 00:00:00",
        "2017-08-01 00:00:00",
        "2017-08-01 00:00:00",
        "2017-08-01 00:00:00"
      ),
      timePeriod = c(
        "month",
        "month",
        "month",
        "month",
        "month",
        "month",
        "month",
        "month",
        "month"
      ),
      source = c(
        "controllers/switch_1",
        "controllers/switch_2",
        "controllers/train_1",
        "controllers/switch_1",
        "controllers/switch_1",
        "controllers/switch_2",
        "controllers/train_1",
        "controllers/switch_1",
        "controllers/switch_2"
      ),
      sourceSystem = c(
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC",
        "controllers/TC"
      ),
      sourceFacility = c(
        "facilities/f1",
        "facilities/f2",
        "facilities/f1",
        "facilities/f1",
        "facilities/f1",
        "facilities/f2",
        "facilities/f1",
        "facilities/f1",
        "facilities/f2"
      ),
      sourceType = c(
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Train",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Train",
        "products/ATS/device_types/Switch",
        "products/ATS/device_types/Switch"
      ),
      episodeRatio = structure(
        c(1L, 1L, 3L, 2L, 1L, 1L, 3L, 2L,
          2L),
        .Label = c(
          "pm_switch_normal",
          "pm_switch_reverse",
          "train_comm_lost",
          "global_failure"
        ),
        class = "factor"
      ),
      episodeRatioGroup = c(
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms",
        "alarms"
      ),
      ratio.ratio = c(
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%",
        "100%"
      ),
      antecedent = c(3L, 3L, 9L, 2L,
                     2L, 2L, 4L, 2L, 1L),
      consequent = c(3L, 3L, 9L, 2L, 2L, 2L, 4L,
                     2L, 1L),
      timestamp = structure(
        c(
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262,
          1499669262
        ),
        tzone = "",
        class = c("POSIXct", "POSIXt")
      ),
      jobId = c(
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d",
        "57c3f486646dcb43c581b70d"
      ),
      type = c(
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio",
        "episodeRatio"
      )
    ),
    class = "data.frame",
    row.names = c(NA, -9L),
    .Names = c(
      "date",
      "timePeriod",
      "source",
      "sourceSystem",
      "sourceFacility",
      "sourceType",
      "episodeRatio",
      "episodeRatioGroup",
      "ratio.ratio",
      "antecedent",
      "consequent",
      "timestamp",
      "jobId",
      "type"
    )
  )

