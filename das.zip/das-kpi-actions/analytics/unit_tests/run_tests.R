rm(list=ls())
library(data.table)
library(plyr)
library(dplyr)
library(lubridate)
library(magrittr)
library(sqldf)
library(mongolite)

library(testthat)
library(mockery)
setwd("C:/Users/zwseda/Documents/r-scripts/other/EventProcessor/unit_tests")

# Testing basic output_table & combinations table
# source("test_cases/test_basic_output.R")
source("test_cases/test_basic_output.R")

# Testing all filtering features
source("test_cases/test_specific_filtering.R")

# Testing aggregations
source("test_cases/test_aggregation.R")

# Testing ratios
source("test_cases/test_ratios.R")

# Testing missing values
source("test_cases/test_missing_data.R")
