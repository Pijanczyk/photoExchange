EVENT_QUERY = '{}'
MEASUREMENT_QUERY = '{}'

#--db connection settings--##
DB_URL <- 'mongodb://127.0.0.1'
DB_NAME <- 'mdc-sdi'
# collection names
EVENT_COLLECTION <- 'sdiEventMessages'
MEASUREMENT_COLLECTION <- 'sdiMeasurementMessages'
OUTPUT_COLLECTION <- 'dasProcessedData'
AGENT_COLLECTION <- 'Reports'

##-- general settings --##

LAST_DATA_LEFT_TIME <- 5 * 60 #* 10 # 10 m
OPERATORS <- c("equals")
AGGREGATION_TYPES <- c("day", "week","month")

# now_for_db <- Sys.time()
# now <- as.numeric(now_for_db) * 1000

in_agentId <- '57c3f486646dcb43c581b70d'
now_for_db <- as.POSIXct("2017-07-10 08:47:42 CEST")
now <- as.numeric(now_for_db) * 1000