#################------------CONFIGURATION--------------#######################


##-- episodes --##
episode_1 <- data.frame(
  episode_name = 'pm_switch_normal',
  event_type_A =  c(
    'products/ATS/event_types/Switch/reverse1',
    'products/ATS/event_types/Switch/reverse2',
    'products/ATS/event_types/Switch/reverse3',
    'products/ATS/event_types/Switch/reverse4'
  ),
  event_state_A = c('off', 'off', 'off', 'off'),
  event_type_B =
    c(
      'products/ATS/event_types/Switch/normal1',
      'products/ATS/event_types/Switch/normal2',
      'products/ATS/event_types/Switch/normal3',
      'timeNow'
    ),
  event_state_B = c('on', 'on', 'on', 'no state')
  
  
)

episode_2 <- data.frame(
  episode_name = 'pm_switch_reverse',
  event_type_A =  c(
    'products/ATS/event_types/Switch/normal1',
    'products/ATS/event_types/Switch/normal2',
    'products/ATS/event_types/Switch/normal3',
    'products/ATS/event_types/Switch/normal4'
  ),
  event_state_A = c('off', 'off', 'off', 'off'),
  event_type_B =
    c(
      'products/ATS/event_types/Switch/reverse1',
      'products/ATS/event_types/Switch/reverse2',
      'products/ATS/event_types/Switch/reverse3',
      'timeNow'
    ),
  event_state_B = c('on', 'on', 'on', 'no state')
)
episode_3 <- data.frame(
  episode_name = 'train_comm_lost',
  event_type_A =  c(
    'products/ATS/event_types/Train/comms_failure1',
    'products/ATS/event_types/Train/comms_failure2',
    'products/ATS/event_types/Train/comms_failure3',
    'products/ATS/event_types/Train/comms_failure4'
  ),
  event_state_A = c('on', 'on', 'on', 'on'),
  event_type_B =
    c(
      'products/ATS/event_types/Train/comms_failure1',
      'products/ATS/event_types/Train/comms_failure2',
      'products/ATS/event_types/Train/comms_failure3',
      'timeNow'
    ),
  event_state_B = c('off', 'off', 'off', 'no state')

)
episode_4 <- data.frame(
  episode_name = 'global_failure',
  event_type_A =  c(
    'event_types/global/failure1',
    'event_types/global/failure2',
    'event_types/global/failure3',
    'event_types/global/failure4'
  ),
  
  event_state_A = c('pulse', 'pulse', 'pulse', 'pulse')
  
)

# you HAVE TO declare list of all episodes to make script work
all_episodes <-
  list(
    episode_1,
    episode_2,
    episode_3,
    episode_4
  )

##-- ratios --##
# episodes A are numerator and episodes B are denominator of the ratio formula

ratio_1 <- data.frame(
  episodes_A_names = c('pm_switch_normal'),
  episodes_B_names = c('pm_switch_normal')
)

ratio_2 <- data.frame(
  episodes_A_names = c('train_comm_lost', 'train_comm_lost'),
  episodes_B_names = c('train_comm_lost')
  
)

ratio_3 <- data.frame(
  episodes_A_names = c('pm_switch_reverse'),
  episodes_B_names = c(
    'pm_switch_reverse',
    'pm_switch_reverse',
    'pm_switch_reverse'
  )
)

ratio_list <- list(ratio_1, ratio_2, ratio_3)
