context("Filtering by measurement and duration")


configuration_path = "configurations/specific_duration_filtering_config.R"
settings = "configurations/general_settings_new.R"
source("before_function.R")
correct_output_table_specifically_filtered_by_duration <-
  test_that("Should give correct output table filtered by specific duration for one device",
            {
              expected <- arrange(specific_duration_filtered_table, date)
              actual <-
                arrange(produce_basic_output(event_data, event_combinations_table),
                        date)
              
              expect_failure(expect_null(actual))
              expect_equal(dim(actual), dim(expected))
              expect_equal(actual, expected)
              expect_equal(length(which(actual$episode == "train_comm_lost")), 3)
              
            })


configuration_path = "configurations/specific_measurement_filtering_config.R"
source("before_function.R")
correct_output_table_filtered_by_measurements <-
  test_that("Should give correct output table filtered by specific measurements for one device",
            {
              expected <- arrange(specific_measurement_filtered_table, date)
              actual <-
                arrange(produce_basic_output(event_data, event_combinations_table),
                        date)
              
              expect_failure(expect_null(actual))
              expect_equal(dim(actual), dim(expected))
              expect_equal(actual, expected)
              expect_equal(length(which(actual$source == "controllers/train_1")), 6)
              
            })
