context("Missing vital values")


configuration_path = "configurations/basic_config.R"
settings = "configurations/general_settings_new.R"
source("before_function_missing.R")
rm(list = c("in_input","in_input2", "all_episodes"))
missing_both_input_and_config <- test_that("Shouldn't work at all without config and input", {

   expect_error(process_event_data_input(in_input), "object 'in_input' not found")
   expect_error(create_event_combinations_table(all_episodes), "object 'all_episodes' not found")
   expect_error(produce_basic_output(event_data,event_combinations_table), "object 'event_data' not found")
  
})

configuration_path = "configurations/basic_config.R"
settings = "configurations/general_settings_new.R"
source("before_function_missing.R")
rm("all_episodes")
missing_config <- test_that("Shouldn't work at all without config", {

  expect_error(process_event_data_input(in_input), "object 'all_episodes' not found")
  expect_error(create_event_combinations_table(all_episodes), "object 'all_episodes' not found")
  expect_error(produce_basic_output(event_data,event_combinations_table), "object 'event_data' not found")
  
})

configuration_path = "configurations/basic_config.R"
settings = "configurations/general_settings_new.R"
source("before_function_missing.R")
all_episodes = list()
empty_config <- test_that("Should give empty output without config", {

  event_data <- process_event_data_input(in_input)
  event_combinations_table <- create_event_combinations_table(all_episodes)
  output <- produce_basic_output(event_data,event_combinations_table)
  
  expect_true(empty(event_combinations_table) & empty(output))
})

configuration_path = "configurations/basic_config.R"
settings = "configurations/general_settings_new.R"
source("before_function_missing.R")
rm("in_input","in_input2")
missing_input <- test_that("Shouldn't work without input", {

  event_combinations_table <- create_event_combinations_table(all_episodes)
  
  expect_error(process_event_data_input(in_input), "object 'in_input' not found")
  expect_true(!empty(event_combinations_table))
  expect_error(produce_basic_output(event_data,event_combinations_table), "object 'event_data' not found")
  
})

configuration_path = "configurations/basic_config.R"
settings = "configurations/general_settings_new.R"
source("before_function_missing.R")
in_input <- data.frame()
in_input <- data.frame()
empty_input <- test_that("Should give empty output tables with empty input", {
  event_combinations_table <- create_event_combinations_table(all_episodes)
  
  expect_error(process_event_data_input(in_input), "object 'sdi_object' not found")
  expect_true(!empty(event_combinations_table))
  expect_error(produce_basic_output(event_data,event_combinations_table), "object 'event_data' not found")
  
})

configuration_path = "configurations/no_time_now_config.R"
settings = "configurations/general_settings_new.R"
source("before_function_missing.R")
no_time_now <- test_that("Should work normally without specified time_now event", {
  event_data <- process_event_data_input(in_input)
  event_combinations_table <- create_event_combinations_table(all_episodes)
  output_table <- produce_basic_output(event_data,event_combinations_table)
  
  expect_equal(dim(event_data), dim(no_time_now_output))
  expect_equal(event_data,no_time_now_output)
  expect_false("timenow" %in% tolower(event_data$eventType))
  expect_true(!empty(event_data) & !empty(event_combinations_table) & !empty(output_table))
})

configuration_path = "configurations/basic_config.R"
settings = "configurations/general_settings_new.R"
source("before_function_missing.R")
rm("in_agentId")
null_agentId <- test_that("Aggregations shouldn't work normally without specified in_agentId", {

  
  event_data <- process_event_data_input(in_input)
  event_combinations_table <- create_event_combinations_table(all_episodes)
  output_table <- produce_basic_output(event_data,event_combinations_table)
  
  expect_true(!empty(event_data) & !empty(event_combinations_table) & !empty(output_table))
  expect_error(aggregate_by_time_range_and_episode(output_table, "day"), "object 'in_agentId' not found")
  expect_error(aggregate_by_time_range_and_episode(output_table, "week"), "object 'in_agentId' not found")
  expect_error(aggregate_by_time_range_and_episode(output_table, "month"), "object 'in_agentId' not found")
})

configuration_path = "configurations/basic_config.R"
settings = "configurations/general_settings_new.R"
source("before_function.R")
AGGREGATION_TYPES <- c("day")
only_day_aggregation_type <- test_that("Should give only one aggregation table", {
  expect_false(empty(aggregate_by_time_range_and_episode(output_table, "day")))
  expect_null(aggregate_by_time_range_and_episode(output_table, "week"))
  expect_null(aggregate_by_time_range_and_episode(output_table, "month"))
})