context("Ratios for day, week, month aggregation")

configuration_path = "configurations/ratio_config.R"
settings = "configurations/general_settings_new.R"
source("before_function.R")
correct_ratios_agg_by_day <-
  test_that("Should give count ratios aggreagated by day", {
    expected <- arrange(ratios_for_day, date)
    actual <- arrange(count_ratios(output_table1, ratio_list), date)
    
    expect_failure(expect_null(actual))
    expect_equal(dim(actual), dim(expected))
    expect_equal(actual, expected)
    expect_equal(length(unique(actual$date)), 6)
    expect_equal(paste0(formatC(100 * actual$antecedent/actual$consequent,format = 'f', digits = 0 ),"%"), expected$ratio.ratio)
    
    
  })

source("before_function.R")
correct_ratios_agg_by_week <-
  test_that("Should give count ratios aggreagated by week", {
    expected <- arrange(ratios_for_week, date)
    actual <- arrange(count_ratios(output_table2, ratio_list), date)
    
    expect_failure(expect_null(actual))
    expect_equal(dim(actual), dim(expected))
    expect_equal(actual, expected)
    expect_equal(length(unique(actual$date)), 2)
    expect_equal(paste0(formatC(100 * actual$antecedent/actual$consequent,format = 'f', digits = 0 ),"%"), expected$ratio.ratio)
    
  })

source("before_function.R")
correct_ratios_agg_by_month <-
  test_that("Should give count ratios aggreagated by month", {
    expected <- arrange(ratios_for_month, date)
    actual <- arrange(count_ratios(output_table3, ratio_list), date)
    
    expect_failure(expect_null(actual))
    expect_equal(dim(actual), dim(expected))
    expect_equal(actual, expected)
    expect_equal(length(unique(actual$date)), 2)
    expect_equal(paste0(formatC(100 * actual$antecedent/actual$consequent,format = 'f', digits = 0 ),"%"), expected$ratio.ratio)
    
  })

