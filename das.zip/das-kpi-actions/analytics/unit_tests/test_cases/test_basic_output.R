context("Output before aggregation and event combinations table")
configuration_path = "configurations/basic_config.R"
settings = "configurations/general_settings_new.R"
source("before_function.R")
correct_combination_table <-
  test_that("Should give all combinations of events", {
    expected <-
      arrange(combination_table,
              event_type_A,
              event_state_A,
              event_type_B,
              event_state_B)
    actual <-
      arrange(
        create_event_combinations_table(all_episodes),
        event_type_A,
        event_state_A,
        event_type_B,
        event_state_B
      )
    
    expect_failure(expect_null(actual))
    expect_equal(dim(actual), dim(expected))
    expect_equal(actual, expected)
  })

source("before_function.R")
correct_event_table <-
  test_that("Should correct formatted events table", {
    expected <- arrange(initial_event_table, event)
    actual <- arrange(process_event_data_input(in_input),event)
    
    expect_failure(expect_null(actual))
    expect_equal(dim(actual), dim(expected))
    expect_equal(actual, expected)
  })

source("before_function.R")
correct_basic_output_table <-
  test_that("Should give correct output table", {
    expected <- arrange(basic_output_table, date)
    actual <- arrange(produce_basic_output(event_data, event_combinations_table),
              date)
    
    expect_failure(expect_null(actual))
    expect_equal(dim(actual), dim(expected))
    expect_equal(actual, expected)
  })
