context("Aggregation by day, week, month")

configuration_path = "configurations/basic_config.R"
settings = "configurations/general_settings_new.R"
source("before_function.R")
correct_output_table_agg_by_day <-
  test_that("Should give correct output table aggregated by day", {
    expected <- arrange(aggregation_by_day, date)
    actual <-
      arrange(aggregate_by_time_range_and_episode(output_table, "day"),
              date)
    
    expect_failure(expect_null(actual))
    expect_equal(dim(actual), dim(expected))
    expect_equal(actual, expected)
    expect_equal(length(unique(actual$date)), 7)
    
    
  })

configuration_path = "configurations/basic_config.R"
settings = "configurations/general_settings_new.R"
source("before_function.R")
correct_output_table_agg_by_week <-
  test_that("Should give correct output table aggregated by week", {
    expected <- arrange(aggregation_by_week, date)
    actual <-
      arrange(aggregate_by_time_range_and_episode(output_table, "week"),
              date)
    
    expect_failure(expect_null(actual))
    expect_equal(dim(actual), dim(expected))
    expect_equal(actual, expected)
    expect_equal(length(unique(actual$date)), 2)
    
  })

source("before_function.R")
correct_output_table_agg_by_month <-
  test_that("Should give correct output table aggregated by month", {
    expected <- arrange(aggregation_by_month, date)
    actual <-
      arrange(aggregate_by_time_range_and_episode(output_table, "month"),
              date)
    
    expect_failure(expect_null(actual))
    expect_equal(dim(actual), dim(expected))
    expect_equal(actual, expected)
    expect_equal(length(unique(actual$date)), 2)
    
  })
