rm(list = setdiff(ls(), c("configuration_path", "settings")))
  script = "../EventProcessor.R"
  source(configuration_path)
  source(settings)
  script_start_line <- 17
  script_end_line <- 676
  execution_block_line <- 655
  
  # Loading artificial datasets & outputs
  for (file in list.files(
    path = c("C:/Users/zwseda/Documents/r-scripts/other/EventProcessor/tests/data/dput_data/","hardcoded_outputs/"),
    pattern = "*.R", full.names = TRUE, ignore.case = TRUE)) {
    source(file)
  }
  
  my_source <- function(file, start, end, ...) {
    file.lines <- scan(file, what=character(), skip=start-1, nlines=end-start+1, sep='\n')
    file.lines.collapsed <- paste(file.lines, collapse='\n')
    source(textConnection(file.lines.collapsed), ...)
  }
  
  my_source(script,script_start_line,execution_block_line)
  
  # mocking db connection
  stub(connect_to_db, "mongo", list(find=0))
  
  for (file in list.files(
    path = c("C:/Users/zwseda/Documents/r-scripts/other/EventProcessor/tests/data/dput_data/"),
    pattern = "*.R", full.names = TRUE, ignore.case = TRUE)) {
    source(file)
  }
  input <- mock(in_input,
                in_input2)
  stub(accessing_data_from_db, "db_connection$find", input)
  stub(output_into_database, "lapply", 0)
  stub(output_into_database, "agent_collection$update", 0)
  stub(output_into_database, "output_collection$remove", 0)
  stub(ignore_state_cases, "lapply", all_episodes)
  

  my_source(script,execution_block_line,script_end_line)
