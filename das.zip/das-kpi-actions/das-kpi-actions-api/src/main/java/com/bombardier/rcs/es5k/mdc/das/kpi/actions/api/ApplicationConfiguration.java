/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.api;

import javax.ws.rs.core.Application;
import javax.ws.rs.ApplicationPath;
import java.util.HashSet;
import java.util.Set;

/**
 * Application Configuration
 *
 * @author Przemyslaw Sikora
 */
@ApplicationPath("/api/v1")
public class ApplicationConfiguration extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        final Set<Class<?>> resources = new HashSet<>();
        resources.add(CORSFilter.class);
        resources.add(JacksonObjectMapperProvider.class);
        resources.add(KpiActionsResource.class);
        return resources;
    }

}
