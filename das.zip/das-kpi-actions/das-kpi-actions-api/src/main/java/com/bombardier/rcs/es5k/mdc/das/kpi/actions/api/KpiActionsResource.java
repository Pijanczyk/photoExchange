/*
 * Copyright (C) 2017 Bombardier Transportation
 */

package com.bombardier.rcs.es5k.mdc.das.kpi.actions.api;

import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.KpiActionsService;
import com.bombardier.rcs.es5k.mdc.das.kpi.actions.display.apimodel.ActionsDataSet;
import com.bombardier.rcs.es5k.mdc.das.kpi.core.display.apimodel.ErrorMessage;
import com.bombardier.rcs.mdc.exception.EntityNotFoundException;
import org.apache.http.HttpStatus;
import org.jboss.resteasy.annotations.GZIP;

import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.logging.Logger;

/**
 * Kpi Actions Resource
 *
 * @author Przemyslaw Sikora
 */
@Path("/actions")
@GZIP
@Produces(MediaType.APPLICATION_JSON)
public class KpiActionsResource {

    private static final Logger logger = Logger.getLogger(KpiActionsResource.class.getName());

    @Inject
    private KpiActionsService kpiActionsService;

    @GET
    public Response retrieveData(
            @QueryParam("kpiConfigId") @NotNull String kpiConfigId,
            @QueryParam("sourceId") String sourceId,
            @QueryParam("deviceTypeId") String deviceTypeId,
            @QueryParam("timeFrom") Long timeFrom,
            @QueryParam("timeTo") Long timeTo
    ) {
        try {
            ActionsDataSet actionsDataSet = kpiActionsService.fetchActionsData(
                    kpiConfigId, sourceId, deviceTypeId, timeFrom, timeTo);
            return Response.ok(actionsDataSet).build();
        } catch (EntityNotFoundException e) {
            logger.fine(e.getMessage());
            return Response.status(HttpStatus.SC_NOT_FOUND).entity(new ErrorMessage(e.getMessage())).build();
        }
    }

}
